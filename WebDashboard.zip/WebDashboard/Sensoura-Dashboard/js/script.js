// Initialize Socket.io connection
const socket = io();
let isMuted = false;
let sensorData = [];
let audioInitialized = false;
let notificationPermission = false;

// Chart configurations
const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    animation: {
        duration: 0
    },
    scales: {
        x: {
            display: false,
            grid: {
                display: false
            }
        },
        y: {
            display: false,
            grid: {
                display: false
            },
            beginAtZero: true
        }
    },
    plugins: {
        legend: {
            display: false
        }
    },
    elements: {
        point: {
            radius: 0
        },
        line: {
            tension: 0.4
        }
    }
};

const mainChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    interaction: {
        intersect: false,
        mode: 'index'
    },
    scales: {
        x: {
            grid: {
                color: 'rgba(255, 255, 255, 0.1)'
            },
            ticks: {
                color: '#94a3b8'
            }
        },
        y: {
            grid: {
                color: 'rgba(255, 255, 255, 0.1)'
            },
            ticks: {
                color: '#94a3b8'
            },
            beginAtZero: true
        }
    },
    plugins: {
        legend: {
            labels: {
                color: '#94a3b8',
                usePointStyle: true
            }
        }
    }
};

// Create mini charts
const gasMiniChart = new Chart(document.getElementById('gasMiniChart'), {
    type: 'line',
    data: {
        labels: [],
        datasets: [{
            data: [],
            borderColor: '#ef4444',
            backgroundColor: 'rgba(239, 68, 68, 0.1)',
            borderWidth: 2,
            fill: true
        }]
    },
    options: chartOptions
});

const soilMiniChart = new Chart(document.getElementById('soilMiniChart'), {
    type: 'line',
    data: {
        labels: [],
        datasets: [{
            data: [],
            borderColor: '#3b82f6',
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            borderWidth: 2,
            fill: true
        }]
    },
    options: chartOptions
});

const tempMiniChart = new Chart(document.getElementById('tempMiniChart'), {
    type: 'line',
    data: {
        labels: [],
        datasets: [{
            data: [],
            borderColor: '#10b981',
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            borderWidth: 2,
            fill: true
        }]
    },
    options: chartOptions
});

const humidityMiniChart = new Chart(document.getElementById('humidityMiniChart'), {
    type: 'line',
    data: {
        labels: [],
        datasets: [{
            data: [],
            borderColor: '#8b5cf6',
            backgroundColor: 'rgba(139, 92, 246, 0.1)',
            borderWidth: 2,
            fill: true
        }]
    },
    options: chartOptions
});

const lightMiniChart = new Chart(document.getElementById('lightMiniChart'), {
    type: 'line',
    data: {
        labels: [],
        datasets: [{
            data: [],
            borderColor: '#f59e0b',
            backgroundColor: 'rgba(245, 158, 11, 0.1)',
            borderWidth: 2,
            fill: true
        }]
    },
    options: chartOptions
});

// Create main chart
const mainChart = new Chart(document.getElementById('mainChart'), {
    type: 'line',
    data: {
        labels: [],
        datasets: [
            {
                label: 'Gas (PPM)',
                data: [],
                borderColor: '#ef4444',
                backgroundColor: 'rgba(239, 68, 68, 0.1)',
                borderWidth: 2,
                fill: false
            },
            {
                label: 'Soil Moisture (AR)',
                data: [],
                borderColor: '#3b82f6',
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                borderWidth: 2,
                fill: false
            },
            {
                label: 'Temperature (°C)',
                data: [],
                borderColor: '#10b981',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                borderWidth: 2,
                fill: false
            },
            {
                label: 'Humidity (%)',
                data: [],
                borderColor: '#8b5cf6',
                backgroundColor: 'rgba(139, 92, 246, 0.1)',
                borderWidth: 2,
                fill: false
            },
            {
                label: 'Light',
                data: [],
                borderColor: '#f59e0b',
                backgroundColor: 'rgba(245, 158, 11, 0.1)',
                borderWidth: 2,
                fill: false
            }
        ]
    },
    options: mainChartOptions
});

// Update chart function
function updateChart(chart, value, maxPoints = 20) {
    const now = new Date().toLocaleTimeString();
    
    chart.data.labels.push(now);
    chart.data.datasets[0].data.push(value);
    
    if (chart.data.labels.length > maxPoints) {
        chart.data.labels.shift();
        chart.data.datasets[0].data.shift();
    }
    
    chart.update('none');
}

// Update main chart function
function updateMainChart(gasValue, soilValue, tempValue, humidityValue, lightValue) {
    const now = new Date().toLocaleTimeString();
    
    mainChart.data.labels.push(now);
    mainChart.data.datasets[0].data.push(gasValue);
    mainChart.data.datasets[1].data.push(soilValue);
    mainChart.data.datasets[2].data.push(tempValue);
    mainChart.data.datasets[3].data.push(humidityValue);
    mainChart.data.datasets[4].data.push(lightValue);
    
    if (mainChart.data.labels.length > 50) {
        mainChart.data.labels.shift();
        mainChart.data.datasets.forEach(dataset => {
            dataset.data.shift();
        });
    }
    
    mainChart.update('none');
}

// Calculate trend
function calculateTrend(currentValue, previousValue) {
    if (!previousValue) return { direction: 'stable', percentage: 0 };
    
    const change = ((currentValue - previousValue) / previousValue) * 100;
    const direction = change > 1 ? 'up' : change < -1 ? 'down' : 'stable';
    
    return { direction, percentage: Math.abs(change).toFixed(1) };
}

// Update status badge
function updateStatusBadge(element, value, sensorType) {
    element.classList.remove('normal', 'warning', 'critical');
    
    if (sensorType === 'gas') {
        if (value < 200) {
            element.classList.add('normal');
            element.textContent = 'SAFE';
        } else if (value < 400) {
            element.classList.add('warning');
            element.textContent = 'WARN';
        } else {
            element.classList.add('critical');
            element.textContent = 'DANGER';
        }
    } 
    else if (sensorType === 'soil') {
        if (value < 350) {
            element.classList.add('critical');
            element.textContent = 'WET';
        } else if (value < 400) {
            element.classList.add('warning');
            element.textContent = 'WW';
        } else if (value < 500) {
            element.classList.add('normal');
            element.textContent = 'SAFE';
        } else if (value < 550) {
            element.classList.add('warning');
            element.textContent = 'DW';
        } else {
            element.classList.add('critical');
            element.textContent = 'DRY';
        }
    }
    else if (sensorType === 'temp') {
        if (value < 15) {
            element.classList.add('normal');
            element.textContent = 'COLD';
        } else if (value < 25) {
            element.classList.add('warning');
            element.textContent = 'CW';
        } else if (value < 45) {
            element.classList.add('normal');
            element.textContent = 'SAFE';
        } else if (value < 50) {
            element.classList.add('warning');
            element.textContent = 'HW';
        } else {
            element.classList.add('critical');
            element.textContent = 'HOT';
        }
    }
    else if (sensorType === 'humidity') {
        if (value < 30) {
            element.classList.add('critical');
            element.textContent = 'DRY';
        } else if (value < 40) {
            element.classList.add('warning');
            element.textContent = 'LOW';
        } else if (value < 70) {
            element.classList.add('normal');
            element.textContent = 'SAFE';
        } else if (value < 80) {
            element.classList.add('warning');
            element.textContent = 'HIGH';
        } else {
            element.classList.add('critical');
            element.textContent = 'HUMID';
        }
    }
    else if (sensorType === 'light') {
        if (value < 100) {
            element.classList.add('critical');
            element.textContent = 'DARK';
        } else if (value < 200) {
            element.classList.add('warning');
            element.textContent = 'LOW';
        } else if (value < 700) {
            element.classList.add('normal');
            element.textContent = 'SAFE';
        } else if (value < 800) {
            element.classList.add('warning');
            element.textContent = 'BRIGHT';
        } else {
            element.classList.add('critical');
            element.textContent = 'VERY BRIGHT';
        }
    }
}

// Update trend indicator
function updateTrendIndicator(element, trend) {
    const icon = element.querySelector('.trend-icon');
    const percent = element.querySelector('.trend-percent');
    
    element.classList.remove('up', 'down', 'stable');
    element.classList.add(trend.direction);
    
    switch (trend.direction) {
        case 'up':
            icon.className = 'fas fa-arrow-up trend-icon';
            break;
        case 'down':
            icon.className = 'fas fa-arrow-down trend-icon';
            break;
        default:
            icon.className = 'fas fa-minus trend-icon';
    }
    
    percent.textContent = `${trend.percentage}%`;
}

// Parse log file data
function parseLogData(logContent) {
    const lines = logContent.split('\n').filter(line => line.trim());
    const parsedData = [];
    
    lines.forEach(line => {
        try {
            // Extract JSON part from the log line
            const jsonStart = line.indexOf('{');
            const jsonEnd = line.lastIndexOf('}');
            
            if (jsonStart !== -1 && jsonEnd !== -1) {
                const jsonStr = line.substring(jsonStart, jsonEnd + 1);
                const data = JSON.parse(jsonStr);
                
                // Extract timestamp from log (the part before JSON)
                const logTimestamp = line.substring(0, jsonStart).trim();
                const timestampMatch = logTimestamp.match(/\[(.*?)\]/);
                const timestamp = timestampMatch ? timestampMatch[1] : new Date().toISOString();
                
                parsedData.push({
                    timestamp: timestamp,
                    gas: data.gas || 0,
                    soil: data.soil || 0,
                    temperature: data.temperature || data.tmp || 0,
                    humidity: data.humidity || 0,
                    light: data.light || 0,
                    local_time: data.local_time || '',
                    utc_time: data.utc_time || ''
                });
            }
        } catch (error) {
            console.error('Error parsing log line:', line, error);
        }
    });
    
    return parsedData;
}

// Fetch and parse logs.txt file
async function fetchLogData() {
    try {
        const response = await fetch('/api/logs');
        if (!response.ok) {
            throw new Error(`Failed to fetch logs: ${response.status} ${response.statusText}`);
        }
        const logContent = await response.text();
        
        if (!logContent.trim()) {
            throw new Error('Log file is empty');
        }
        
        const parsedData = parseLogData(logContent);
        console.log(`Successfully parsed ${parsedData.length} records from logs.txt`);
        return parsedData;
        
    } catch (error) {
        console.error('Error fetching log data:', error);
        console.log('Falling back to current session data');
        // Return current session data as fallback
        return sensorData.map(item => ({
            timestamp: item.timestamp.toISOString(),
            gas: item.gas,
            soil: item.soil,
            temperature: item.temperature,
            humidity: item.humidity,
            light: item.light,
            local_time: '',
            utc_time: item.timestamp.toISOString()
        }));
    }
}

// ===================== AUDIO SYSTEM =====================

function initAudio() {
    if (audioInitialized) return;
    
    // Create and play a silent audio to unlock sound
    const silentAudio = new Audio();
    silentAudio.src = "data:audio/wav;base64,UklGRigAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQQAAAAAAA==";
    silentAudio.volume = 0;
    
    silentAudio.play().then(() => {
        audioInitialized = true;
        console.log('✅ Audio unlocked');
    }).catch(e => {
        console.log('🔇 Audio initialization failed:', e);
    });
}

function playAlertSound() {
    if (!audioInitialized) {
        console.log('🔇 Click anywhere to enable sounds');
        return;
    }
    
    try {
        const context = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = context.createOscillator();
        const gainNode = context.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(context.destination);
        
        oscillator.frequency.value = 800;
        oscillator.type = 'sine';
        gainNode.gain.value = 0.1;
        
        oscillator.start();
        oscillator.stop(context.currentTime + 0.3);
        
    } catch (e) {
        console.log('🔇 Sound error:', e);
    }
}

// ===================== NOTIFICATION SYSTEM =====================

// Notification system
let lastSensorStates = {
    gas: 'normal',
    soil: 'normal',
    temp: 'normal',
    humidity: 'normal',
    light: 'normal'
};

// Show desktop notification
function showNotification(title, message, sensorType) {
    if (!notificationPermission) return;
    
    const notification = new Notification(title, {
        body: message,
        icon: '/favicon_io/favicon-32x32.png',
        tag: `sensor-${sensorType}`,
        requireInteraction: false
    });
    
    // Auto close after 4 seconds
    setTimeout(() => {
        notification.close();
    }, 4000);
    
    // Only play sound for critical alerts and if audio is ready
    if ((title.includes('DANGER') || title.includes('CRITICAL')) && audioInitialized) {
        playAlertSound();
    }
}

// Check for sensor state changes and trigger notifications
function checkSensorStateChanges(currentData) {
    const currentStates = {
        gas: getSensorState('gas', currentData.gas),
        soil: getSensorState('soil', currentData.soil),
        temp: getSensorState('temp', currentData.temperature),
        humidity: getSensorState('humidity', currentData.humidity),
        light: getSensorState('light', currentData.light)
    };
    
    // Check each sensor for state changes
    checkSingleSensor('gas', currentStates.gas, currentData.gas, 'PPM');
    checkSingleSensor('soil', currentStates.soil, currentData.soil, 'AR');
    checkSingleSensor('temp', currentStates.temp, currentData.temperature, '°C');
    checkSingleSensor('humidity', currentStates.humidity, currentData.humidity, '%');
    checkSingleSensor('light', currentStates.light, currentData.light, '');
    
    // Update last states
    lastSensorStates = currentStates;
}

// Check individual sensor state change
function checkSingleSensor(sensorKey, currentState, value, unit) {
    const lastState = lastSensorStates[sensorKey];
    
    if (currentState !== lastState) {
        const sensorName = getSensorName(sensorKey);
        const stateText = getStateText(currentState);
        
        const title = `${sensorName} - ${stateText}`;
        const message = `Current value: ${value} ${unit}. State changed from ${getStateText(lastState)} to ${stateText}`;
        
        showNotification(title, message, getSensorType(sensorKey));
        
        console.log(`🔔 ${sensorName} state changed: ${lastState} → ${currentState}`);
    }
}

// Get sensor display name
function getSensorName(sensorKey) {
    const names = {
        gas: 'Gas Sensor',
        soil: 'Soil Moisture',
        temp: 'Temperature Sensor',
        humidity: 'Humidity Sensor',
        light: 'Light Sensor'
    };
    return names[sensorKey] || sensorKey;
}

// Get sensor type for icons
function getSensorType(sensorKey) {
    return sensorKey;
}

// Get sensor state based on value
function getSensorState(sensorType, value) {
    if (sensorType === 'gas') {
        if (value < 200) return 'normal';
        if (value < 400) return 'warning';
        return 'critical';
    } 
    else if (sensorType === 'soil') {
        if (value < 350) return 'critical';
        if (value < 400) return 'warning';
        if (value < 500) return 'normal';
        if (value < 550) return 'warning';
        return 'critical';
    }
    else if (sensorType === 'temp') {
        if (value < 15) return 'normal';
        if (value < 25) return 'warning';
        if (value < 45) return 'normal';
        if (value < 50) return 'warning';
        return 'critical';
    }
    else if (sensorType === 'humidity') {
        if (value < 30) return 'critical';
        if (value < 40) return 'warning';
        if (value < 70) return 'normal';
        if (value < 80) return 'warning';
        return 'critical';
    }
    else if (sensorType === 'light') {
        if (value < 100) return 'critical';
        if (value < 200) return 'warning';
        if (value < 700) return 'normal';
        if (value < 800) return 'warning';
        return 'critical';
    }
    return 'normal';
}

// Get state display text
function getStateText(state) {
    const texts = {
        normal: 'SAFE',
        warning: 'WARNING', 
        critical: 'DANGER'
    };
    return texts[state] || state.toUpperCase();
}

// Update notification button state
function updateNotificationButton(enabled) {
    const btn = document.getElementById('notificationBtn');
    const icon = document.getElementById('notificationIcon');
    const text = document.getElementById('notificationText');
    
    if (!btn) return;
    
    // إزالة جميع الكلاسات
    btn.classList.remove('enabled', 'disabled', 'pending');
    
    if (Notification.permission === "granted" && enabled) {
        btn.classList.add('enabled');
        icon.className = 'fas fa-bell';
        text.textContent = 'Notifications ON';
        btn.title = 'Click to disable notifications';
    } else if (Notification.permission === "denied") {
        btn.classList.add('disabled');
        icon.className = 'fas fa-bell-slash';
        text.textContent = 'Notifications Blocked';
        btn.title = 'Notifications are blocked by browser';
    } else {
        btn.classList.add('pending');
        icon.className = 'fas fa-bell';
        text.textContent = 'Enable Notifications';
        btn.title = 'Click to enable notifications';
    }
}

// Toggle notification permissions
function toggleNotifications() {
    if (!("Notification" in window)) {
        alert("This browser does not support desktop notification");
        return;
    }

    console.log('Before toggle - Permission:', Notification.permission, 'Enabled:', notificationPermission);

    if (Notification.permission === "granted") {
        // Toggle the current state
        notificationPermission = !notificationPermission;
        updateNotificationButton(notificationPermission);
        
        if (notificationPermission) {
            console.log('🔔 Notifications enabled');
            showTemporaryAlert('Notifications turned ON', 'success');
            // Show test notification
            showNotification('Sensora Dashboard', 'Notifications are now enabled!', 'system');
        } else {
            console.log('🔕 Notifications disabled');
            showTemporaryAlert('Notifications turned OFF', 'warning');
        }
        
    } else if (Notification.permission === "denied") {
        // If denied, show instructions to enable
        showTemporaryAlert('Notifications blocked in browser settings', 'error');
        setTimeout(() => {
            if (confirm('Notifications are blocked. Would you like to learn how to enable them?')) {
                window.open('https://support.google.com/chrome/answer/3220216', '_blank');
            }
        }, 1000);
        
    } else {
        // If not decided, request permission
        Notification.requestPermission().then(permission => {
            console.log('Permission result:', permission);
            
            if (permission === "granted") {
                notificationPermission = true;
                updateNotificationButton(true);
                console.log('🔔 Notifications enabled');
                showTemporaryAlert('Notifications turned ON', 'success');
                
                // Show welcome notification
                showNotification('Sensora Dashboard', 'Notifications are now enabled!', 'system');
            } else {
                notificationPermission = false;
                updateNotificationButton(false);
                console.log('🔕 Notifications permission denied');
                showTemporaryAlert('Notifications permission denied', 'error');
            }
        }).catch(error => {
            console.error('Error requesting notification permission:', error);
            showTemporaryAlert('Error requesting notification permission', 'error');
        });
    }
    
    console.log('After toggle - Permission:', Notification.permission, 'Enabled:', notificationPermission);
}

// دالة مساعدة لعرض تنبيهات مؤقتة
function showTemporaryAlert(message, type = 'info') {
    // إنشاء عنصر التنبيه
    const alertDiv = document.createElement('div');
    alertDiv.className = `temp-alert ${type}`;
    alertDiv.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'warning' ? 'exclamation-triangle' : 'info-circle'}"></i>
        <span>${message}</span>
    `;
    
    // إضافة الستايل
    alertDiv.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${type === 'success' ? '#10b981' : type === 'warning' ? '#f59e0b' : '#ef4444'};
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        display: flex;
        align-items: center;
        gap: 10px;
        animation: slideInRight 0.3s ease;
    `;
    
    document.body.appendChild(alertDiv);
    
    // إزالة التنبيه بعد 3 ثواني
    setTimeout(() => {
        alertDiv.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.parentNode.removeChild(alertDiv);
            }
        }, 300);
    }, 3000);
}

// ===================== RELAY CONTROL FUNCTIONS =====================

// Send relay command to server
function sendRelayCommand(command) {
    console.log(`🔌 Sending relay command: ${command}`);
    
    let overlayId;
    
    if (command === 'ON') {
        overlayId = 'relayOnOverlay';
    } else if (command === 'OFF') {
        overlayId = 'relayOffOverlay';
    } else if (command === 'AUTO') {
        overlayId = 'relayAutoOverlay';
    }
    
    const overlay = document.getElementById(overlayId);
    if (overlay) overlay.classList.add('show');
    
    // إرسال الأمر عبر السوكيت
    if (command === 'AUTO') {
        socket.emit('relayModeToggle', 'AUTO');
    } else if (command === 'MANUAL') {
        // الانتقال للمانوال مع إبقاء الحالة الحالية
        const currentState = document.getElementById('relayBtn').classList.contains('active') ? 'ON' : 'OFF';
        socket.emit('relayToggle', currentState === 'ON');
    } else {
        socket.emit('relayToggle', command === 'ON');
    }
    
    setTimeout(() => {
        if (overlay) overlay.classList.remove('show');
    }, 3000);
}

// Update relay UI elements - الإصدار المصحح
function updateRelayUI(relayData) {
    const relayBtn = document.getElementById('relayBtn');
    const relayIcon = document.getElementById('relayIcon');
    const relayText = document.getElementById('relayBtnText');
    const relayStatus = document.getElementById('relayStatus');
    const relayFooterIcon = document.getElementById('relayFooterIcon');
    const relayFooterText = document.getElementById('relayFooterText');
    const relayModeIndicator = document.getElementById('relayModeIndicator');
    
    if (!relayBtn) {
        console.error('❌ Relay button element not found');
        return;
    }
    
    const isManualMode = relayData.mode === 'MANUAL';
    const isRelayOn = relayData.state === 'High' || relayData.state === 'ON' || relayData.state === true;
    
    console.log(`🔄 Updating relay UI: State=${relayData.state}, Mode=${relayData.mode}, isManual=${isManualMode}, isOn=${isRelayOn}`);
    
    // تحديث زر الريلاي الرئيسي
    if (isRelayOn) {
        relayBtn.classList.add('active');
        relayIcon.className = 'fas fa-toggle-on';
    } else {
        relayBtn.classList.remove('active');
        relayIcon.className = 'fas fa-toggle-off';
    }
    
    // تحديث نص الزر بناءً على الوضع
    if (isManualMode) {
        relayText.textContent = isRelayOn ? 'Turn Off' : 'Turn On';
    } else {
        relayText.textContent = 'Auto Mode';
    }
    
    // تحديث حالة الريلاي في الهيدر
    if (relayStatus) {
        relayStatus.textContent = `RELAY ${isRelayOn ? 'ON' : 'OFF'} (${isManualMode ? 'MANUAL' : 'AUTO'})`;
        relayStatus.className = isRelayOn ? 'active' : '';
        relayStatus.classList.add(isManualMode ? 'manual' : 'auto');
    }
    
    // تحديث الفوتر
    if (relayFooterIcon && relayFooterText) {
        relayFooterIcon.className = `fas fa-toggle-${isRelayOn ? 'on' : 'off'} status-icon ${isRelayOn ? 'active' : ''}`;
        relayFooterText.textContent = `Relay ${isRelayOn ? 'ON' : 'OFF'} - ${isManualMode ? 'Manual' : 'Auto'}`;
    }
    
    // تحديث مؤشر الوضع
    if (relayModeIndicator) {
        relayModeIndicator.textContent = isManualMode ? 'MANUAL' : 'AUTO';
        relayModeIndicator.className = `mode-indicator ${isManualMode ? 'manual' : 'auto'}`;
    }
}

// ===================== BUZZER CONTROL FUNCTIONS =====================

// Send mute command to server
function sendMuteCommand(isMuted) {
    console.log(`🔊 Sending mute command: ${isMuted ? 'MUTE' : 'UNMUTE'}`);
    
    const overlay = document.getElementById(isMuted ? 'muteoverlay' : 'unmuteoverlay');
    if (overlay) overlay.classList.add('show');
    
    // إرسال الأمر عبر السوكيت
    socket.emit('muteToggle', isMuted);
    
    setTimeout(() => {
        if (overlay) overlay.classList.remove('show');
    }, 3000);
}

// Show mobile command alert
function showWebDashboardAlert(sender, action) {
    const alert = document.getElementById('WebDashboardAlert');
    const message = document.getElementById('alertMessage');
    
    if (alert && message) {
        message.textContent = `${sender} ${action === 'MUTE' ? 'muted' : 'unmuted'} the buzzer`;
        alert.style.display = 'block';
        
        setTimeout(() => {
            closeAlert();
        }, 5000);
    }
}

// Close alert banner
function closeAlert() {
    const alert = document.getElementById('WebDashboardAlert');
    if (alert) alert.style.display = 'none';
}

// Close modal
function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.remove('show');
}

// Update buzzer UI elements
function updateBuzzerUI(isMuted) {
    const stateText = document.getElementById('buzzerStateText');
    const footerIcon = document.getElementById('buzzerFooterIcon');
    const footerText = document.getElementById('buzzerFooterText');
    const muteBtn = document.getElementById('muteBtn');
    const muteIcon = document.getElementById('muteIcon');
    const muteText = document.getElementById('muteBtnText');
    
    console.log(`🎵 Updating buzzer UI: ${isMuted ? 'MUTED' : 'UNMUTED'}`);
    
    if (stateText) {
        stateText.textContent = isMuted ? 'MUTED' : 'UNMUTED';
        stateText.className = isMuted ? 'muted' : '';
    }
    
    if (footerIcon && footerText) {
        footerIcon.className = isMuted ? 'fas fa-bell-slash status-icon' : 'fas fa-bell status-icon';
        footerText.textContent = isMuted ? 'Buzzer Muted' : 'Buzzer Active';
    }
    
    if (muteBtn && muteIcon && muteText) {
        muteIcon.className = isMuted ? 'fas fa-volume-mute' : 'fas fa-volume-up';
        muteText.textContent = isMuted ? 'Unmute Buzzer' : 'Mute Buzzer';
        if (isMuted) {
            muteBtn.classList.add('muted');
        } else {
            muteBtn.classList.remove('muted');
        }
    }
    
    // Update global state
    window.isMuted = isMuted;
}

// ===================== SOCKET EVENT HANDLERS =====================

socket.on('connect', () => {
    console.log('✅ Connected to server');
    document.getElementById('connectionIcon').className = 'fas fa-wifi status-icon';
    document.getElementById('connectionText').textContent = 'Io.Connected';
    document.getElementById('loadingOverlay').classList.remove('show');
    document.getElementById('statusPulse').style.display = 'block';
    document.getElementById('system-status').textContent = 'Socket.io Active';
    document.getElementById('system-status-indicator').className = 'fas fa-circle status-icon active';
    
    // Request current status on connect
    socket.emit('getMuteStatus');
    socket.emit('getRelayStatus');
    socket.emit('getSystemStatus');
});

socket.on('disconnect', () => {
    console.log('❌ Disconnected from server');
    document.getElementById('connectionIcon').className = 'fas fa-wifi-slash status-icon';
    document.getElementById('connectionText').textContent = 'IO.Disconnected';
    document.getElementById('statusPulse').style.display = 'none';
    document.getElementById('system-status').textContent = 'Socket.io deactive';
    document.getElementById('system-status-indicator').className = 'fas fa-circle status-icon deactive';
});

socket.on('sensorData', (data) => {
    console.log('📊 Received sensor data:', data);
    
    // Store previous values for trend calculation
    const previousGas = sensorData.length > 0 ? sensorData[sensorData.length - 1].gas : null;
    const previousSoil = sensorData.length > 0 ? sensorData[sensorData.length - 1].soil : null;
    const previousTemp = sensorData.length > 0 ? sensorData[sensorData.length - 1].temperature : null;
    const previousHumidity = sensorData.length > 0 ? sensorData[sensorData.length - 1].humidity : null;
    const previousLight = sensorData.length > 0 ? sensorData[sensorData.length - 1].light : null;
    
    // Store current data
    sensorData.push({
        ...data,
        timestamp: new Date()
    });
    
    // Keep only last 1000 readings
    if (sensorData.length > 1000) {
        sensorData.shift();
    }
    
    // Update display values
    document.getElementById('gasValue').textContent = data.gas;
    document.getElementById('soilValue').textContent = data.soil;
    document.getElementById('tempValue').textContent = data.temperature || data.tmp;
    document.getElementById('humidityValue').textContent = data.humidity;
    document.getElementById('lightValue').textContent = data.light;
    document.getElementById('lastUpdate').textContent = new Date().toLocaleTimeString();
    
    // Update status badges
    updateStatusBadge(document.getElementById('gasStatus'), data.gas, 'gas');
    updateStatusBadge(document.getElementById('soilStatus'), data.soil, 'soil');
    updateStatusBadge(document.getElementById('tempStatus'), data.temperature || data.tmp, 'temp');
    updateStatusBadge(document.getElementById('humidityStatus'), data.humidity, 'humidity');
    updateStatusBadge(document.getElementById('lightStatus'), data.light, 'light');
    
    // Update trend indicators
    updateTrendIndicator(document.getElementById('gasTrend'), calculateTrend(data.gas, previousGas));
    updateTrendIndicator(document.getElementById('soilTrend'), calculateTrend(data.soil, previousSoil));
    updateTrendIndicator(document.getElementById('tempTrend'), calculateTrend(data.temperature || data.tmp, previousTemp));
    updateTrendIndicator(document.getElementById('humidityTrend'), calculateTrend(data.humidity, previousHumidity));
    updateTrendIndicator(document.getElementById('lightTrend'), calculateTrend(data.light, previousLight));
    
    // Update charts
    updateChart(gasMiniChart, data.gas);
    updateChart(soilMiniChart, data.soil);
    updateChart(tempMiniChart, data.temperature || data.tmp);
    updateChart(humidityMiniChart, data.humidity);
    updateChart(lightMiniChart, data.light);
    updateMainChart(data.gas, data.soil, data.temperature || data.tmp, data.humidity, data.light);
    
    // Update system status
    updateSystemStatusDisplay(data.system_status);
    
    // Update relay state from sensor data
    if (data.relay_state && data.relay_mode) {
        updateRelayUI({
            state: data.relay_state,
            mode: data.relay_mode
        });
    }
    
    // Update buzzer state from sensor data
    if (data.arduino_buzzer_state) {
        const isMuted = data.arduino_buzzer_state === 'MUTED';
        updateBuzzerUI(isMuted);
    }
    
    // 🔔 Check for sensor state changes and show notifications
    checkSensorStateChanges(data);
    
    // Update status indicators
    if (typeof updateStatusIndicators === 'function') {
        updateStatusIndicators(data);
    }
});

// Update system status display
function updateSystemStatusDisplay(systemStatus) {
    const systemStatusElement = document.getElementById('system-status');
    const systemStatusIndicator = document.getElementById('system-status-indicator');
    
    if (systemStatusElement && systemStatusIndicator) {
        systemStatusElement.textContent = systemStatus || 'Active';
        
        if (systemStatus === 'Safe' || systemStatus === 'Active') {
            systemStatusIndicator.className = 'fas fa-circle status-icon active';
        } else if (systemStatus === 'Warn' || systemStatus === 'Warning') {
            systemStatusIndicator.className = 'fas fa-circle status-icon warning';
        } else {
            systemStatusIndicator.className = 'fas fa-circle status-icon deactive';
        }
    }
}

// Mute status updates
socket.on('muteStatus', (data) => {
    console.log('🔊 Mute status update:', data);
    
    if (data.success) {
        updateBuzzerUI(data.muted);
        
        // Show success modal
        document.getElementById('successMessage').textContent = data.message;
        document.getElementById('successModal').classList.add('show');
    } else {
        // Show error message
        showTemporaryAlert(`Error: ${data.message}`, 'error');
    }
});

// Relay status updates
socket.on('relayStatus', (data) => {
    console.log('🔌 Relay status update:', data);
    
    if (data.success) {
        updateRelayUI({
            state: data.relayOn ? 'ON' : 'OFF',
            mode: data.relayMode || 'AUTO'
        });
        
        // Show success modal
        document.getElementById('successMessage').textContent = data.message;
        document.getElementById('successModal').classList.add('show');
    } else {
        // Show error message
        showTemporaryAlert(`Error: ${data.message}`, 'error');
    }
});

// System status response
socket.on('systemStatus', (data) => {
    console.log('🖥️ System status:', data);
    // يمكن تحديث واجهة المستخدم بناءً على حالة النظام
});

// Mobile command notifications
socket.on('mobileCommand', (data) => {
    console.log('📱 Mobile command received:', data);
    showWebDashboardAlert(data.sentBy, data.action);
    if (data.action === 'MUTE' || data.action === 'UNMUTE') {
        updateBuzzerUI(data.action === 'MUTE');
    }
});

// Mobile relay command notifications
socket.on('mobileRelayCommand', (data) => {
    console.log('📱 Mobile relay command received:', data);
    showTemporaryAlert(`Mobile app ${data.action} relay`, 'info');
    updateRelayUI({
        state: data.action === 'ON' ? 'ON' : 'OFF',
        mode: data.action === 'AUTO' ? 'AUTO' : 'MANUAL'
    });
});

// Command execution confirmation
socket.on('commandExecuted', (data) => {
    console.log(`✅ Command executed: ${data.action} by ${data.sentBy}`);
    if (data.action === 'MUTE' || data.action === 'UNMUTE') {
        updateBuzzerUI(data.action === 'MUTE');
    }
});

// Relay command execution confirmation
socket.on('relayCommandExecuted', (data) => {
    console.log(`✅ Relay command executed: ${data.action} by ${data.sentBy}`);
    updateRelayUI({
        state: data.action === 'ON' ? 'ON' : 'OFF',
        mode: data.action === 'AUTO' ? 'AUTO' : 'MANUAL'
    });
});

// Buzzer state updates from Firebase
socket.on('buzzerStateUpdate', (data) => {
    console.log(`🎵 Buzzer state update: ${data.state}`);
    const isMuted = data.state === 'MUTED';
    updateBuzzerUI(isMuted);
});

// Relay state updates from Firebase
socket.on('relayStateUpdate', (data) => {
    console.log(`⚡ Relay state update: ${data.state}`);
    updateRelayUI({
        state: data.state,
        mode: 'MANUAL'
    });
});

// Connection status with Arduino
socket.on('connectionStatus', (data) => {
    console.log('🔗 Connection status:', data);
    if (data.arduinoConnected) {
        document.getElementById('system-status').textContent = 'Arduino Connected';
        document.getElementById('system-status-indicator').className = 'fas fa-circle status-icon active';
    } else {
        document.getElementById('system-status').textContent = 'Arduino Disconnected';
        document.getElementById('system-status-indicator').className = 'fas fa-circle status-icon warning';
    }
});

// ===================== EVENT LISTENERS =====================

// Mute button functionality
document.getElementById('muteBtn').addEventListener('click', function() {
    isMuted = !isMuted;
    sendMuteCommand(isMuted);
});

// Relay button functionality - الإصدار المصحح
document.getElementById('relayBtn').addEventListener('click', function() {
    const currentMode = document.getElementById('relayModeIndicator').textContent;
    const isCurrentlyOn = this.classList.contains('active');
    
    console.log(`🔌 Relay button clicked: CurrentMode=${currentMode}, isOn=${isCurrentlyOn}`);
    
    if (currentMode === 'AUTO') {
        // الانتقال من AUTO إلى MANUAL ON
        sendRelayCommand('ON');
    } else {
        // في MANUAL mode - تبديل ON/OFF
        sendRelayCommand(isCurrentlyOn ? 'OFF' : 'ON');
    }
});

// زر تغيير الوضع - الإصدار المصحح
document.getElementById('relayModeBtn').addEventListener('click', function() {
    const currentMode = document.getElementById('relayModeIndicator').textContent;
    console.log(`🔄 Switching relay mode from: ${currentMode}`);
    
    if (currentMode === 'AUTO') {
        sendRelayCommand('MANUAL');
    } else {
        sendRelayCommand('AUTO');
    }
});

// Theme toggle functionality
document.getElementById('themeToggle').addEventListener('change', function() {
    document.body.classList.toggle('dark-theme', this.checked);
    localStorage.setItem('darkTheme', this.checked);
});

// Notification button functionality
document.getElementById('notificationBtn').addEventListener('click', function() {
    toggleNotifications();
});

// Export CSV functionality
document.getElementById('exportBtn').addEventListener('click', async function() {
    const button = this;
    const originalText = button.innerHTML;
    
    try {
        // Show loading state
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading Data...';
        button.disabled = true;
        
        // Fetch data from logs.txt via API
        const logData = await fetchLogData();
        
        if (logData.length === 0) {
            alert('No data found in logs.txt or current session');
            return;
        }
        
        // Create CSV content
        const csvContent = [
            'Log Timestamp,Local Time,UTC Time,Gas (PPM),Soil Moisture (AR),Temperature (°C),Humidity (%),Light',
            ...logData.map(row => 
                `"${row.timestamp}","${row.local_time}","${row.utc_time}",${row.gas},${row.soil},${row.temperature},${row.humidity},${row.light}`
            )
        ].join('\n');
        
        // Create and download CSV file
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `sensor-data-export-${new Date().toISOString().split('T')[0]}-${Date.now()}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        console.log(`✅ Exported ${logData.length} records to CSV`);
        showTemporaryAlert(`Successfully exported ${logData.length} records to CSV`, 'success');
        
    } catch (error) {
        console.error('Error exporting CSV:', error);
        showTemporaryAlert('Error exporting data: ' + error.message, 'error');
    } finally {
        // Restore button state
        button.innerHTML = originalText;
        button.disabled = false;
    }
});

// Chart period buttons
document.querySelectorAll('.chart-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.chart-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        
        // Here you could implement different time periods
        console.log('Selected period:', this.dataset.period);
    });
});

// Initialize audio on any user interaction
document.addEventListener('click', initAudio, { once: true });
document.addEventListener('keydown', initAudio, { once: true });

// ===================== INITIALIZATION =====================

// Initialize notification system when page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Initializing Sensora Dashboard...');
    
    // Initialize notification system
    notificationPermission = Notification.permission === "granted";
    updateNotificationButton(notificationPermission);
    
    // Initialize theme
    if (localStorage.getItem('darkTheme') === 'true') {
        document.getElementById('themeToggle').checked = true;
        document.body.classList.add('dark-theme');
    }
    
    // Load user data
    const name = localStorage.getItem('name');
    if (name) {
        document.getElementById('username').textContent = name;
        document.getElementById('mobileUsername').textContent = name;
    }
    
    // Initialize relay state
    setTimeout(() => {
        updateRelayUI({
            state: 'OFF',
            mode: 'AUTO'
        });
        
        updateBuzzerUI(false);
    }, 1000);
    
    // Show welcome notification if enabled
    setTimeout(() => {
        if (notificationPermission) {
            showNotification('Sensora Dashboard', 'Sensor monitoring is now active!', 'system');
        }
    }, 2000);
    
    console.log('✅ Dashboard initialization complete');
});

// Show loading overlay initially and hide after 5 seconds
document.getElementById('loadingOverlay').classList.add('show');
setTimeout(() => {
    document.getElementById('loadingOverlay').classList.remove('show');
}, 5000);

// Enhanced status indicator updates
function updateStatusIndicator(sensorType, status) {
    const indicator = document.getElementById(`${sensorType}StatusIndicator`);
    if (indicator) {
        indicator.className = `card-status-indicator ${status}`;
    }
}

// Update all status indicators when sensor data is received
window.updateStatusIndicators = function(data) {
    updateStatusIndicator('gas', getSensorState('gas', data.gas));
    updateStatusIndicator('soil', getSensorState('soil', data.soil));
    updateStatusIndicator('temp', getSensorState('temp', data.temperature || data.tmp));
    updateStatusIndicator('humidity', getSensorState('humidity', data.humidity));
    updateStatusIndicator('light', getSensorState('light', data.light));
};

// إضافة أنيميشن للـ CSS
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOutRight {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    
    .temp-alert {
        animation: slideInRight 0.3s ease;
    }
    
    .temp-alert.hiding {
        animation: slideOutRight 0.3s ease;
    }
`;
document.head.appendChild(style);

console.log('🎯 Sensora Dashboard script loaded successfully!');
// ===================== AI Analysis Functions =====================

// DOM Elements for AI
const runAnalysisBtn = document.getElementById('runAnalysisBtn');
const refreshAnalysisBtn = document.getElementById('refreshAnalysisBtn');
const aiHealthScore = document.getElementById('aiHealthScore');
const aiHealthStatus = document.getElementById('aiHealthStatus');
const aiHealthBadge = document.getElementById('aiHealthBadge');
const aiHealthCircle = document.getElementById('aiHealthCircle');
const aiGrowthStage = document.getElementById('aiGrowthStage');
const aiLastAnalysis = document.getElementById('aiLastAnalysis');
const aiRecommendationsCount = document.getElementById('aiRecommendationsCount');
const aiAlertsCount = document.getElementById('aiAlertsCount');
const aiRecommendationsList = document.getElementById('aiRecommendationsList');
const aiAlertsList = document.getElementById('aiAlertsList');
const aiWeatherData = document.getElementById('aiWeatherData');

// Socket.io events for AI
socket.on('aiAnalysisStatus', function(data) {
    console.log('🤖 AI Analysis Status:', data);
    
    if (data.status === 'processing') {
        showAILoading();
    } else if (data.status === 'completed') {
        hideAILoading();
        showTemporaryAlert('AI analysis completed successfully', 'success');
    } else if (data.status === 'error') {
        hideAILoading();
        showTemporaryAlert('AI analysis failed: ' + data.message, 'error');
    }
});

socket.on('aiAnalysisUpdate', function(data) {
    console.log('🤖 AI Analysis Update:', data);
    updateAIDashboard(data);
});

socket.on('aiAnalysisHistory', function(data) {
    console.log('🤖 AI Analysis History:', data);
    // يمكن استخدامها لعرض التاريخ إذا أردت
});

// Update AI Dashboard
function updateAIDashboard(analysisData) {
    try {
        const aiAnalysis = analysisData.ai_analysis;
        const metadata = analysisData.metadata;
        
        // Update health score
        updateHealthScore(aiAnalysis.health.score, aiAnalysis.health.status);
        
        // Update growth stage
        updateGrowthStage(aiAnalysis.growth_stage);
        
        // Update last analysis time
        updateLastAnalysisTime(metadata.analysis_timestamp);
        
        // Update counts
        updateCounts(aiAnalysis);
        
        // Update recommendations
        updateRecommendations(aiAnalysis.recommendations);
        
        // Update alerts
        updateAlerts(aiAnalysis.critical_alerts);
        
        // Update weather data
        if (analysisData.weather_data) {
            updateWeatherData(analysisData.weather_data);
        }
        
        // Show success animation
        showUpdateAnimation();
        
        console.log('✅ AI Dashboard updated successfully');
        
    } catch (error) {
        console.error('❌ Error updating AI dashboard:', error);
    }
}

// Update health score
function updateHealthScore(score, status) {
    if (aiHealthScore) aiHealthScore.textContent = score;
    if (aiHealthStatus) aiHealthStatus.textContent = status;
    
    // Update badge
    if (aiHealthBadge) {
        aiHealthBadge.textContent = status;
        aiHealthBadge.className = 'status-badge';
        aiHealthBadge.classList.add(status.toLowerCase());
    }
    
    // Update circle gradient
    if (aiHealthCircle) {
        // Calculate percentage for conic gradient
        const percentage = score;
        
        // Set color based on score
        let color;
        if (score >= 85) color = 'var(--status-normal)';
        else if (score >= 70) color = '#10b981'; // Lighter green
        else if (score >= 55) color = 'var(--status-warning)';
        else if (score >= 40) color = '#f59e0b'; // Darker orange
        else color = 'var(--status-critical)';
        
        // Update circle gradient
        aiHealthCircle.style.background = `conic-gradient(
            ${color} 0%,
            ${color} ${percentage}%,
            var(--border-color) ${percentage}%,
            var(--border-color) 100%
        )`;
        
        // Add animation class
        aiHealthCircle.classList.remove('updated', 'critical-updated');
        if (score >= 70) {
            aiHealthCircle.classList.add('updated');
        } else if (score < 40) {
            aiHealthCircle.classList.add('critical-updated');
        }
    }
}

// Update growth stage
function updateGrowthStage(stage) {
    if (aiGrowthStage) {
        const stageNames = {
            'seedling': '🌱 Seedling',
            'vegetative': '🌿 Vegetative',
            'tuber_formation': '🥔 Tuber Formation',
            'harvest': '🕒 Harvest'
        };
        aiGrowthStage.textContent = stageNames[stage] || stage;
    }
}

// Update last analysis time
function updateLastAnalysisTime(timestamp) {
    if (aiLastAnalysis) {
        const time = new Date(timestamp);
        const now = new Date();
        const diffMinutes = Math.floor((now - time) / (1000 * 60));
        
        let timeText;
        if (diffMinutes < 1) {
            timeText = 'Just now';
        } else if (diffMinutes < 60) {
            timeText = `${diffMinutes} minutes ago`;
        } else if (diffMinutes < 1440) {
            const hours = Math.floor(diffMinutes / 60);
            timeText = `${hours} hour${hours > 1 ? 's' : ''} ago`;
        } else {
            timeText = time.toLocaleString();
        }
        
        aiLastAnalysis.textContent = timeText;
    }
}

// Update counts
function updateCounts(analysis) {
    if (aiRecommendationsCount) {
        aiRecommendationsCount.textContent = analysis.recommendations.length;
    }
    if (aiAlertsCount) {
        aiAlertsCount.textContent = analysis.critical_alerts.length;
    }
}

// Update recommendations
function updateRecommendations(recommendations) {
    if (!aiRecommendationsList) return;
    
    if (recommendations.length === 0) {
        aiRecommendationsList.innerHTML = '<div class="no-data">No recommendations available</div>';
        return;
    }
    
    const recommendationsHTML = recommendations.map(rec => `
        <div class="recommendation-item">
            <div class="recommendation-header">
                <div class="recommendation-title">
                    ${rec.title || rec.type}
                </div>
                <div class="recommendation-priority ${rec.priority.toLowerCase()}">
                    ${rec.priority}
                </div>
            </div>
            <div class="recommendation-message">
                ${rec.message || ''}
            </div>
            <div class="recommendation-action">
                <i class="fas fa-play-circle"></i>
                ${rec.action}
            </div>
        </div>
    `).join('');
    
    aiRecommendationsList.innerHTML = recommendationsHTML;
}

// Update alerts
function updateAlerts(alerts) {
    if (!aiAlertsList) return;
    
    if (alerts.length === 0) {
        aiAlertsList.innerHTML = '<div class="no-data">No critical alerts detected</div>';
        return;
    }
    
    const alertsHTML = alerts.map(alert => `
        <div class="alert-item">
            <div class="alert-header">
                <div class="alert-title">
                    <i class="fas fa-exclamation-triangle"></i>
                    ${alert.title}
                </div>
                <div class="alert-severity ${alert.severity.toLowerCase()}">
                    ${alert.severity}
                </div>
            </div>
            <div class="alert-message">
                ${alert.message}
            </div>
            <div class="alert-action">
                <i class="fas fa-bolt"></i>
                ${alert.action}
            </div>
        </div>
    `).join('');
    
    aiAlertsList.innerHTML = alertsHTML;
}

// Update weather data
function updateWeatherData(weather) {
    if (!aiWeatherData) return;
    
    const weatherHTML = `
        <div class="weather-item">
            <div class="weather-value">
                ${weather.current ? weather.current.temperature.toFixed(1) : '--'}
                <span class="weather-unit">°C</span>
            </div>
            <div class="weather-label">Current Temp</div>
        </div>
        <div class="weather-item">
            <div class="weather-value">
                ${weather.current ? weather.current.humidity.toFixed(0) : '--'}
                <span class="weather-unit">%</span>
            </div>
            <div class="weather-label">Humidity</div>
        </div>
        <div class="weather-item">
            <div class="weather-value">
                ${weather.today ? weather.today.max_temp.toFixed(1) : '--'}
                <span class="weather-unit">°C</span>
            </div>
            <div class="weather-label">Max Today</div>
        </div>
        <div class="weather-item">
            <div class="weather-value">
                ${weather.today ? weather.today.precipitation.toFixed(1) : '0'}
                <span class="weather-unit">mm</span>
            </div>
            <div class="weather-label">Rainfall</div>
        </div>
    `;
    
    aiWeatherData.innerHTML = weatherHTML;
}

// Show loading state
function showAILoading() {
    const loadingHTML = `
        <div class="ai-loading">
            <div class="spinner"></div>
            <p>AI Analysis in Progress...</p>
            <small>Analyzing sensor data and weather conditions</small>
        </div>
    `;
    
    // Replace content with loading state
    const sections = [aiRecommendationsList, aiAlertsList, aiWeatherData];
    sections.forEach(section => {
        if (section) {
            section.dataset.originalContent = section.innerHTML;
            section.innerHTML = loadingHTML;
        }
    });
    
    // Disable buttons
    if (runAnalysisBtn) runAnalysisBtn.disabled = true;
    if (refreshAnalysisBtn) refreshAnalysisBtn.disabled = true;
}

// Hide loading state
function hideAILoading() {
    // Re-enable buttons
    if (runAnalysisBtn) runAnalysisBtn.disabled = false;
    if (refreshAnalysisBtn) refreshAnalysisBtn.disabled = false;
}

// Show update animation
function showUpdateAnimation() {
    // Add visual feedback
    const aiPanel = document.querySelector('.ai-panel');
    if (aiPanel) {
        aiPanel.style.transform = 'translateY(-4px)';
        aiPanel.style.boxShadow = '0 12px 48px rgba(139, 92, 246, 0.3)';
        
        setTimeout(() => {
            aiPanel.style.transform = '';
            aiPanel.style.boxShadow = '';
        }, 300);
    }
}

// Initialize AI Dashboard
function initAIDashboard() {
    console.log('🤖 Initializing AI Dashboard...');
    
    // Request current AI analysis on load
    setTimeout(() => {
        socket.emit('getCurrentAIAnalysis');
    }, 2000);
    
    // Subscribe to AI updates
    socket.emit('subscribeToAIUpdates');
    
    // Set up event listeners
    if (runAnalysisBtn) {
        runAnalysisBtn.addEventListener('click', function() {
            console.log('🤖 Manual AI analysis requested');
            socket.emit('triggerAIAnalysis');
            showTemporaryAlert('AI analysis started...', 'info');
        });
    }
    
    if (refreshAnalysisBtn) {
        refreshAnalysisBtn.addEventListener('click', function() {
            console.log('🤖 Refreshing AI analysis');
            socket.emit('getCurrentAIAnalysis');
            showTemporaryAlert('Refreshing AI analysis...', 'info');
        });
    }
    
    console.log('✅ AI Dashboard initialized');
}

// Get current AI analysis from server
function getCurrentAIAnalysis() {
    // Try to get from localStorage first
    const cachedAnalysis = localStorage.getItem('lastAIAnalysis');
    if (cachedAnalysis) {
        try {
            const analysis = JSON.parse(cachedAnalysis);
            updateAIDashboard(analysis);
            console.log('📦 Loaded AI analysis from cache');
        } catch (error) {
            console.error('❌ Error parsing cached analysis:', error);
        }
    }
    
    // Always request fresh data from server
    socket.emit('getCurrentAIAnalysis');
}

// ===================== Initialize AI When Page Loads =====================
document.addEventListener('DOMContentLoaded', function() {
    // Initialize AI dashboard after a short delay
    setTimeout(() => {
        if (document.querySelector('.ai-panel')) {
            initAIDashboard();
        }
    }, 1000);
    
    // Also initialize when socket connects
    socket.on('connect', function() {
        setTimeout(() => {
            if (document.querySelector('.ai-panel')) {
                initAIDashboard();
            }
        }, 500);
    });
});

// ===================== Integration with Existing System =====================

// عندما تأتي بيانات جديدة من السينسورات، يمكن تشغيل التحليل تلقائياً
socket.on('sensorData', function(data) {
    // يمكنك إضافة منطق هنا لتشغيل التحليل عند تغيير كبير في البيانات
    // مثلاً:
    // checkForAutoAnalysis(data);
});

// دالة للتحقق من الحاجة لتحليل تلقائي
function checkForAutoAnalysis(currentData) {
    // حفظ آخر قيمة للتربة
    const lastSoilValue = localStorage.getItem('lastSoilValue');
    const currentSoilValue = currentData.soil;
    
    // إذا كانت قيمة التربة تغيرت بشكل كبير (فرق أكثر من 100)
    if (lastSoilValue && Math.abs(currentSoilValue - lastSoilValue) > 100) {
        console.log('🌱 Significant soil change detected, auto-triggering AI analysis');
        socket.emit('triggerAIAnalysis');
    }
    
    // حفظ القيمة الحالية
    localStorage.setItem('lastSoilValue', currentSoilValue);
}

// حفظ آخر تحليل في localStorage
socket.on('aiAnalysisUpdate', function(data) {
    try {
        localStorage.setItem('lastAIAnalysis', JSON.stringify(data));
        localStorage.setItem('lastAIAnalysisTime', new Date().toISOString());
    } catch (error) {
        console.error('❌ Error saving analysis to cache:', error);
    }
});

// ===================== Helper Functions =====================

// Format time difference
function formatTimeDifference(timestamp) {
    const time = new Date(timestamp);
    const now = new Date();
    const diffMs = now - time;
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)}h ago`;
    return time.toLocaleDateString();
}

// Play sound for critical alerts
function playAlertSoundForAI() {
    if (audioInitialized) {
        const context = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = context.createOscillator();
        const gainNode = context.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(context.destination);
        
        oscillator.frequency.value = 600;
        oscillator.type = 'sine';
        gainNode.gain.value = 0.1;
        
        oscillator.start();
        oscillator.stop(context.currentTime + 0.5);
    }
}

console.log('🤖 AI Analysis module loaded successfully!');