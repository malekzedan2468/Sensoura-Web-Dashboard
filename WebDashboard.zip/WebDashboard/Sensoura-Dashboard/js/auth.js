// js/auth.js - FIXED VERSION
function protectPage() {
  const name = localStorage.getItem('name');
  const gender = localStorage.getItem('gender');
  const email = localStorage.getItem('email');
  const token = localStorage.getItem('token');

  if (!token || !name || !gender || !email) {
    location.href = 'Login.html';
    return;
  }

  // Safely update user info only if elements exist
  try {
    const usernameElement = document.getElementById('username');
    const emailElement = document.getElementById('email');
    const genderElement = document.getElementById('gender');
    
    if (usernameElement) usernameElement.innerText = name;
    if (emailElement) emailElement.innerText = email;
    if (genderElement) genderElement.innerText = gender || 'N/A';
    
  } catch (error) {
    console.log('Auth: Some user info elements not found in this page');
  }
}

function logout() {
  // Clear all stored data
  localStorage.removeItem('token');
  localStorage.removeItem('name');
  localStorage.removeItem('gender');
  localStorage.removeItem('email');
  localStorage.removeItem('darkTheme');
  
  // Redirect to login page
  location.href = 'Login.html';
}

// Enhanced protect function with token validation
async function protectPageWithValidation() {
  const token = localStorage.getItem('token');
  const name = localStorage.getItem('name');
  
  if (!token || !name) {
    logout();
    return;
  }

  try {
    // Optional: Validate token with server
    const response = await fetch('/api/auth/validate', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) {
      throw new Error('Token validation failed');
    }
    
    protectPage();
  } catch (error) {
    console.error('Auth validation error:', error);
    logout();
  }
}

// Check if user is logged in (for conditional rendering)
function isLoggedIn() {
  return localStorage.getItem('token') && localStorage.getItem('name');
}

// Get current user info
function getCurrentUser() {
  return {
    name: localStorage.getItem('name'),
    email: localStorage.getItem('email'),
    gender: localStorage.getItem('gender'),
    token: localStorage.getItem('token')
  };
}

// Safe element updater
function updateUserInfo() {
  const user = getCurrentUser();
  const usernameElement = document.getElementById('username');
  const emailElement = document.getElementById('email');
  const genderElement = document.getElementById('gender');
  
  if (usernameElement && user.name) usernameElement.textContent = user.name;
  if (emailElement && user.email) emailElement.textContent = user.email;
  if (genderElement && user.gender) genderElement.textContent = user.gender;
}

// Auto-protect only on pages that need protection
function autoProtect() {
  const excludedPages = ['/Login.html', '/login.html', '/register.html', '/Register.html'];
  const currentPage = window.location.pathname.split('/').pop();
  
  if (!excludedPages.includes(currentPage)) {
    protectPage();
  }
}

// Initialize when DOM is loaded
if (typeof window !== 'undefined') {
  document.addEventListener('DOMContentLoaded', autoProtect);
}