const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');

const User = require('../models/User');
const sendVerificationEmail = require('../utils/sendVerificationEmail');

// 🔹 Register route
router.post('/register', async (req, res) => {
  const { name, email, password, gender } = req.body;

  try {
    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser)
      return res.status(400).json({ message: 'Email already exists' });

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create verification token
    const verifyToken = crypto.randomBytes(160).toString('hex');

    // Create user
    const user = new User({
      name,
      email,
      password: hashedPassword,
      gender,
      verifyToken,
      isVerified: false
    });

    await user.save();

    // Send verification email
    await sendVerificationEmail(email, name, verifyToken);

    res
      .status(201)
      .json({ message: 'User registered. Please verify your email.' });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

// 🔹 Verify Email route
router.get('/verify-email', async (req, res) => {
  const { token } = req.query;

  try {
    const user = await User.findOne({ verifyToken: token });
    if (!user) {
      return res.status(400).send('Invalid or expired verification token.');
    }

    user.isVerified = true;
    user.verifyToken = undefined;
    await user.save();

    res.send('✅ Email verified successfully! You can now log in.');
  } catch (err) {
    console.error('Email verification error:', err);
    res.status(500).send('Server error during verification.');
  }
});

// 🔹 Login route
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    // Find user
    const user = await User.findOne({ email });
    if (!user)
      return res.status(400).json({ message: 'Invalid credentials' });

    // Check if email is verified
    if (!user.isVerified) {
      return res.status(401).json({ message: 'Please verify your email first.' });
    }

    // Compare password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch)
      return res.status(400).json({ message: 'Invalid credentials' });

    // Create JWT
    const token = jwt.sign(
      { id: user._id, name: user.name },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    res.json({ token, name: user.name, gender: user.gender });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
