// backend/utils/sendVerificationEmail.js
const { Resend } = require('resend');
const dotenv = require('dotenv');
dotenv.config();
const resend = new Resend(process.env.RESEND_API_KEY);

async function sendVerificationEmail(email, name, token) {
  const verificationLink = `http://localhost:5000/api/auth/verify-email?token=${token}`;

  try {
    const { data, error } = await resend.emails.send({
      from: '<ur-email>',
      to: email,
      subject: 'Verify your email',
      html: `<p>Hello ${name},</p>
             <p>Please verify your email by clicking the link below:</p>
             <a href="${verificationLink}">Verify Email</a>`
    });

    if (error) {
      console.error('Email send error:', error);
    }
  } catch (err) {
    console.error(err);
  }
}

module.exports = sendVerificationEmail;
