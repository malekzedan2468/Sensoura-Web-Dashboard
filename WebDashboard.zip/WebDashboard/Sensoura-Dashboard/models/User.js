const mongoose = require('mongoose');

// models/User.js
const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  password: String,
  gender: String,
  isVerified: { type: Boolean, default: false },
  verifyToken: String,
});


module.exports = mongoose.model('User', userSchema);
