// server.js - Complete Integrated System with AI Analysis & Real-time Updates
const express = require('express');
const admin = require("firebase-admin");
const axios = require('axios');
const cron = require('node-cron');
const cors = require('cors');
const http = require('http');
const fs = require('fs');
const path = require('path');
const socketio = require('socket.io');

const dotenv = require('dotenv');
dotenv.config();

// ==================== Firebase Setup ====================
const serviceAccountPath = path.join(__dirname, "sensora-68eda-firebase-adminsdk-fbsvc-aa3ba2ea95.json");

if (!fs.existsSync(serviceAccountPath)) {
  console.error("Firebase service account JSON not found at:", serviceAccountPath);
  process.exit(1);
}

const serviceAccount = require(serviceAccountPath);

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: process.env.FIREBASE_DB_URL || "https://sensora-68eda-default-rtdb.europe-west1.firebasedatabase.app",
});

const db = admin.database();
const sensorRef = db.ref("sensorData");
const commandsRef = db.ref("buzzerCommands");
const relayCommandsRef = db.ref("relayCommands");
const farmStateRef = db.ref("farm_state");
const farmStateHistoryRef = db.ref("farm_state_history");
const systemRef = db.ref("system");

// ==================== AI Analysis System Setup ====================
// Open-Meteo API
const OPEN_METEO_URL = 'https://api.open-meteo.com/v1/forecast';

// Egypt coordinates for weather
const LOCATIONS = {
  "GH_01": { lat: 30.0444, lon: 31.2357 }, // Cairo
  "GH_02": { lat: 31.2001, lon: 29.9187 }, // Alexandria
  "GH_03": { lat: 30.7875, lon: 31.0000 }  // Delta Region
};

// Potato Growth Stages Handbook
const POTATO_HANDBOOK = {
  "growth_stages": {
    "seedling": {
      "duration_days": 21,
      "temperature": { "optimal": [18, 25], "acceptable": [15, 28], "critical": [10, 35] },
      "humidity": { "optimal": [40, 70], "acceptable": [30, 80], "critical": [20, 90] },
      "soil_moisture": { 
        "optimal": [400, 550], 
        "acceptable": [350, 600], 
        "critical": [300, 900],
        "notes": "ADC value 0-1023 (Higher = drier)"
      },
      "light": { "optimal": [500, 700], "acceptable": [400, 800], "critical": [200, 1000] },
      "co2": { "optimal": [400, 800], "acceptable": [300, 1000], "critical": [200, 1500] }
    },
    "vegetative": {
      "duration_days": 35,
      "temperature": { "optimal": [20, 28], "acceptable": [18, 32], "critical": [12, 35] },
      "humidity": { "optimal": [50, 75], "acceptable": [40, 80], "critical": [30, 90] },
      "soil_moisture": { "optimal": [400, 550], "acceptable": [350, 600], "critical": [300, 900] },
      "light": { "optimal": [600, 800], "acceptable": [500, 900], "critical": [300, 1200] },
      "co2": { "optimal": [400, 800], "acceptable": [300, 1000], "critical": [200, 1500] }
    },
    "tuber_formation": {
      "duration_days": 34,
      "temperature": { "optimal": [15, 25], "acceptable": [12, 28], "critical": [8, 32] },
      "humidity": { "optimal": [60, 80], "acceptable": [50, 85], "critical": [40, 95] },
      "soil_moisture": { "optimal": [400, 550], "acceptable": [350, 600], "critical": [300, 900] },
      "light": { "optimal": [500, 700], "acceptable": [400, 800], "critical": [200, 1000] },
      "co2": { "optimal": [400, 800], "acceptable": [300, 1000], "critical": [200, 1500] }
    },
    "harvest": {
      "duration_days": 21,
      "temperature": { "optimal": [15, 28], "acceptable": [12, 32], "critical": [5, 35] },
      "humidity": { "optimal": [40, 70], "acceptable": [30, 80], "critical": [20, 90] },
      "soil_moisture": { "optimal": [350, 500], "acceptable": [300, 550], "critical": [250, 900] },
      "light": { "optimal": [400, 700], "acceptable": [300, 800], "critical": [200, 1000] },
      "co2": { "optimal": [400, 800], "acceptable": [300, 1000], "critical": [200, 1500] }
    }
  },
  "stress_conditions": {
    "temperature": {
      "too_low": "Growth slows; frost risk; tuber formation stops",
      "too_high": "Tuber formation inhibited; leaf burn; premature aging"
    },
    "humidity": {
      "too_low": "Plants dry out; growth slows; leaf curl",
      "too_high": "Risk of fungal diseases (Late Blight, Early Blight)"
    },
    "soil_moisture": {
      "too_low": "Plants wilt; tuber quality reduced; yield loss",
      "too_high": "Root rot risk; tuber cracking; oxygen deprivation"
    },
    "light": {
      "too_low": "Slow growth; elongated stems; small leaves",
      "too_high": "Leaf burn; reduced photosynthesis; heat stress"
    },
    "co2": {
      "too_low": "Reduced photosynthesis; slow growth",
      "too_high": "Plant stress; ventilation needed"
    }
  },
  "disease_risks": {
    "high_humidity": ["Late Blight", "Early Blight", "White Mold"],
    "high_temperature": ["Bacterial Wilt", "Common Scab"],
    "waterlogged_soil": ["Root Rot", "Blackleg", "Soft Rot"],
    "poor_air_quality": ["Powdery Mildew", "Botrytis"]
  },
  "optimal_conditions": {
    "ph_soil": [5.0, 6.5],
    "ec_level": [1.5, 2.5],
    "planting_depth_cm": [10, 15],
    "spacing_cm": [30, 40],
    "fertilizer_npk": "5-10-10 for tubers"
  }
};

// Global variables
let plantType = "Potato"; // Default plant type
let currentFarmState = null;
let lastAnalysisResult = null;
let aiAnalysisHistory = [];

// ==================== Express App ====================
const app = express();
app.use(cors());
app.use(express.json());

// ==================== Routes ====================
// Mobile buzzer command
app.post('/api/buzzer/command', async (req, res) => {
  try {
    const { action, sentBy = 'mobile_app', deviceId } = req.body;
    const actionUpper = String(action || '').toUpperCase().trim();
    const sender = String(sentBy || 'mobile_app');
    const device = String(deviceId || '');

    if (!actionUpper || (actionUpper !== 'MUTE' && actionUpper !== 'UNMUTE')) {
      return res.status(400).json({
        success: false,
        message: 'Invalid action. Use MUTE or UNMUTE'
      });
    }

    const timestamp = new Date().toISOString();

    const commandData = {
      action: actionUpper,
      timestamp,
      sentBy: sender,
      deviceId: device || null,
      status: 'pending'
    };

    const newCommandRef = commandsRef.push();
    await newCommandRef.set(commandData);

    console.log(`📱 Mobile command saved to Firebase: ${actionUpper} from ${sender}`);

    if (global.ioInstance) {
      global.ioInstance.emit('mobileCommand', {
        action: actionUpper,
        sentBy: sender,
        timestamp
      });
    }

    res.json({
      success: true,
      message: `Command ${actionUpper} sent successfully`,
      commandId: newCommandRef.key
    });

  } catch (error) {
    console.error('❌ Error saving mobile command:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to send command'
    });
  }
});

// Mobile relay command
app.post('/api/relay/command', async (req, res) => {
  try {
    const { action, sentBy = 'mobile_app', deviceId } = req.body;
    const actionUpper = String(action || '').toUpperCase().trim();
    const sender = String(sentBy || 'mobile_app');
    const device = String(deviceId || '');

    if (!actionUpper || (actionUpper !== 'ON' && actionUpper !== 'OFF' && actionUpper !== 'AUTO')) {
      return res.status(400).json({
        success: false,
        message: 'Invalid action. Use ON, OFF or AUTO'
      });
    }

    const timestamp = new Date().toISOString();

    const commandData = {
      action: actionUpper,
      timestamp,
      sentBy: sender,
      deviceId: device || null,
      status: 'pending',
      type: 'relay'
    };

    const newCommandRef = relayCommandsRef.push();
    await newCommandRef.set(commandData);

    console.log(`📱 Mobile relay command saved to Firebase: ${actionUpper} from ${sender}`);

    if (global.ioInstance) {
      global.ioInstance.emit('mobileRelayCommand', {
        action: actionUpper,
        sentBy: sender,
        timestamp
      });
    }

    res.json({
      success: true,
      message: `Relay command ${actionUpper} sent successfully`,
      commandId: newCommandRef.key
    });

  } catch (error) {
    console.error('❌ Error saving mobile relay command:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to send relay command'
    });
  }
});

// Status endpoint
app.get('/', (req, res) => {
  res.send('🤖 Sensora AI System is running...');
});

app.get('/api/status', (req, res) => {
  res.json({
    status: 'online',
    timestamp: new Date().toISOString(),
    service: 'Sensora AI Monitoring System',
    ai_enabled: true,
    last_analysis: lastAnalysisResult ? lastAnalysisResult.timestamp : null
  });
});

// Get AI Analysis results
app.get('/api/ai/analysis', async (req, res) => {
  try {
    const { limit = 10 } = req.query;
    
    if (lastAnalysisResult) {
      res.json({
        success: true,
        current: lastAnalysisResult,
        history: aiAnalysisHistory.slice(0, limit),
        count: aiAnalysisHistory.length
      });
    } else {
      // Run analysis if not available
      const analysis = await performAIAnalysis();
      res.json({
        success: true,
        current: analysis,
        history: aiAnalysisHistory.slice(0, limit)
      });
    }
  } catch (error) {
    console.error('❌ Error getting AI analysis:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get AI analysis'
    });
  }
});

// Trigger manual AI analysis
app.post('/api/ai/analyze', async (req, res) => {
  try {
    console.log('🔍 Manual AI analysis triggered via API');
    const analysis = await performAIAnalysis();
    
    res.json({
      success: true,
      message: 'AI analysis completed successfully',
      analysis: analysis
    });
  } catch (error) {
    console.error('❌ Error in manual AI analysis:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to perform AI analysis'
    });
  }
});

// Get dashboard data
app.get('/api/dashboard', async (req, res) => {
  try {
    const dashboardRef = db.ref('dashboard');
    const snapshot = await dashboardRef.once('value');
    
    if (snapshot.exists()) {
      res.json({
        success: true,
        data: snapshot.val()
      });
    } else {
      res.json({
        success: false,
        message: 'No dashboard data available'
      });
    }
  } catch (error) {
    console.error('❌ Error fetching dashboard:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch dashboard data'
    });
  }
});

// ==================== Farm State Endpoints ====================
app.get('/farm_state', async (req, res) => {
  try {
    const snapshot = await farmStateRef.once('value');
    
    if (!snapshot.exists()) {
      return res.status(404).json({ error: 'No farm state data available' });
    }

    res.json(snapshot.val());
  } catch (err) {
    console.error('❌ Error fetching farm_state:', err);
    res.status(500).json({ error: 'Failed to fetch farm_state' });
  }
});

app.get('/farm_state/history', async (req, res) => {
  try {
    const { limit = 100, startAt, endAt } = req.query;
    let historyQuery = farmStateHistoryRef.orderByChild('timestamp').limitToLast(parseInt(limit));
    
    if (startAt) {
      historyQuery = historyQuery.startAt(startAt);
    }
    
    if (endAt) {
      historyQuery = historyQuery.endAt(endAt);
    }
    
    const snapshot = await historyQuery.once('value');
    
    if (!snapshot.exists()) {
      return res.json({ history: [] });
    }

    const historyData = [];
    snapshot.forEach(child => {
      historyData.push({
        id: child.key,
        ...child.val()
      });
    });

    historyData.reverse();

    res.json({
      count: historyData.length,
      history: historyData
    });
  } catch (err) {
    console.error('❌ Error fetching farm_state history:', err);
    res.status(500).json({ error: 'Failed to fetch farm_state history' });
  }
});

app.get('/farm_state/history/latest', async (req, res) => {
  try {
    const { limit = 10 } = req.query;
    const snapshot = await farmStateHistoryRef.orderByChild('timestamp').limitToLast(parseInt(limit)).once('value');
    
    if (!snapshot.exists()) {
      return res.json({ history: [] });
    }

    const historyData = [];
    snapshot.forEach(child => {
      historyData.unshift({
        id: child.key,
        ...child.val()
      });
    });

    res.json({
      count: historyData.length,
      history: historyData
    });
  } catch (err) {
    console.error('❌ Error fetching latest farm_state history:', err);
    res.status(500).json({ error: 'Failed to fetch latest farm_state history' });
  }
});

// ==================== AI Analysis Functions ====================
async function getWeatherData(greenhouseId) {
  try {
    const location = LOCATIONS[greenhouseId] || LOCATIONS["GH_01"];
    
    const response = await axios.get(OPEN_METEO_URL, {
      params: {
        latitude: location.lat,
        longitude: location.lon,
        current: 'temperature_2m,relative_humidity_2m,wind_speed_10m,precipitation',
        hourly: 'temperature_2m,relative_humidity_2m,precipitation_probability',
        daily: 'temperature_2m_max,temperature_2m_min,precipitation_sum',
        timezone: 'Africa/Cairo',
        forecast_days: 2
      }
    });
    
    return {
      current: {
        temperature: response.data.current.temperature_2m,
        humidity: response.data.current.relative_humidity_2m,
        wind_speed: response.data.current.wind_speed_10m,
        precipitation: response.data.current.precipitation,
        timestamp: new Date().toISOString()
      },
      today: {
        max_temp: response.data.daily.temperature_2m_max[0],
        min_temp: response.data.daily.temperature_2m_min[0],
        precipitation: response.data.daily.precipitation_sum[0]
      },
      tomorrow: {
        max_temp: response.data.daily.temperature_2m_max[1],
        min_temp: response.data.daily.temperature_2m_min[1],
        precipitation: response.data.daily.precipitation_sum[1]
      },
      hourly_forecast: response.data.hourly,
      location: location
    };
  } catch (error) {
    console.error(`🌤️ Weather API error for ${greenhouseId}:`, error.message);
    return null;
  }
}

function detectGrowthStage(plantingDate = null) {
  if (plantingDate) {
    try {
      const plantDate = new Date(plantingDate);
      const today = new Date();
      const daysSince = Math.floor((today - plantDate) / (1000 * 60 * 60 * 24));
      
      if (daysSince < 21) return "seedling";
      if (daysSince >= 21 && daysSince < 56) return "vegetative";
      if (daysSince >= 56 && daysSince < 90) return "tuber_formation";
      return "harvest";
    } catch (error) {
      console.error('Error calculating growth stage:', error);
    }
  }
  
  const month = new Date().getMonth() + 1;
  if (month >= 1 && month <= 3) return "vegetative";
  if (month >= 4 && month <= 6) return "tuber_formation";
  if (month >= 7 && month <= 9) return "seedling";
  return "harvest";
}

function analyzePotatoGrowth(sensorData, growthStage, weatherData, systemStatus) {
  const recommendations = [];
  const warnings = [];
  const criticalAlerts = [];
  let healthScore = 100;
  
  const stageData = POTATO_HANDBOOK.growth_stages[growthStage];
  const stressData = POTATO_HANDBOOK.stress_conditions;
  
  function evaluateParameter(value, paramName, unit = '') {
    if (value === null || value === undefined) {
      return { status: 'NO_DATA', message: `No ${paramName} data available` };
    }
    
    const optimal = stageData[paramName]?.optimal || [0, 100];
    const acceptable = stageData[paramName]?.acceptable || [0, 100];
    const critical = stageData[paramName]?.critical || [0, 100];
    
    if (value < critical[0] || value > critical[1]) {
      return { 
        status: 'CRITICAL', 
        range: critical,
        optimal: optimal,
        current: value,
        unit: unit
      };
    }
    
    if (value < acceptable[0] || value > acceptable[1]) {
      return { 
        status: 'OUT_OF_RANGE', 
        range: acceptable,
        optimal: optimal,
        current: value,
        unit: unit
      };
    }
    
    if (value < optimal[0] || value > optimal[1]) {
      return { 
        status: 'SUBOPTIMAL', 
        range: acceptable,
        optimal: optimal,
        current: value,
        unit: unit
      };
    }
    
    return { 
      status: 'OPTIMAL', 
      range: optimal,
      current: value,
      unit: unit
    };
  }
  
  // Temperature Analysis
  if (sensorData.temperature !== null) {
    const tempEval = evaluateParameter(sensorData.temperature, 'temperature', '°C');
    
    if (tempEval.status === 'CRITICAL') {
      const isLow = sensorData.temperature < tempEval.range[0];
      criticalAlerts.push({
        type: 'TEMPERATURE_CRITICAL',
        severity: 'CRITICAL',
        title: isLow ? '❄️ CRITICAL: Temperature Too Low' : '🔥 CRITICAL: Temperature Too High',
        message: isLow 
          ? `Temperature (${sensorData.temperature}°C) is below critical minimum (${tempEval.range[0]}°C)`
          : `Temperature (${sensorData.temperature}°C) is above critical maximum (${tempEval.range[1]}°C)`,
        action: isLow 
          ? 'IMMEDIATE: Activate all heating systems, use thermal blankets'
          : 'IMMEDIATE: Activate cooling, increase ventilation, use shade nets',
        impact: stressData.temperature[isLow ? 'too_low' : 'too_high']
      });
      healthScore -= 40;
    } 
    else if (tempEval.status === 'OUT_OF_RANGE') {
      const isLow = sensorData.temperature < tempEval.range[0];
      recommendations.push({
        type: 'TEMPERATURE',
        priority: 'HIGH',
        title: isLow ? '🌡️ Temperature Low' : '🌡️ Temperature High',
        message: `Temperature (${sensorData.temperature}°C) is outside acceptable range`,
        action: isLow 
          ? 'Increase temperature using heating system'
          : 'Reduce temperature using ventilation/cooling',
        optimal: `${tempEval.optimal[0]} - ${tempEval.optimal[1]}°C`,
        current: `${sensorData.temperature}°C`,
        deviation: isLow 
          ? `${(tempEval.range[0] - sensorData.temperature).toFixed(1)}°C below minimum`
          : `${(sensorData.temperature - tempEval.range[1]).toFixed(1)}°C above maximum`
      });
      healthScore -= 25;
    }
  }
  
  // Humidity Analysis
  if (sensorData.humidity !== null) {
    const humidityEval = evaluateParameter(sensorData.humidity, 'humidity', '%');
    
    if (humidityEval.status === 'CRITICAL') {
      const isHigh = sensorData.humidity > humidityEval.range[1];
      warnings.push({
        type: 'HUMIDITY_CRITICAL',
        severity: 'HIGH',
        title: isHigh ? '💧 CRITICAL: Humidity Extremely High' : '💧 CRITICAL: Humidity Extremely Low',
        message: `Humidity (${sensorData.humidity}%) is at critical level`,
        action: isHigh 
          ? 'Increase ventilation immediately, check for condensation'
          : 'Increase misting/watering frequency',
        disease_risk: isHigh ? POTATO_HANDBOOK.disease_risks.high_humidity.join(', ') : 'Plant dehydration'
      });
      healthScore -= 30;
    }
    else if (humidityEval.status === 'OUT_OF_RANGE' && sensorData.humidity > 80) {
      warnings.push({
        type: 'FUNGAL_RISK',
        severity: 'MEDIUM',
        title: '⚠️ High Humidity Alert',
        message: `Humidity (${sensorData.humidity}%) increases fungal disease risk`,
        action: 'Increase air circulation, monitor for leaf spots',
        diseases: POTATO_HANDBOOK.disease_risks.high_humidity.join(', ')
      });
      healthScore -= 15;
    }
  }
  
  // Soil Moisture Analysis
  if (sensorData.soil_moisture !== null) {
    const soilEval = evaluateParameter(sensorData.soil_moisture, 'soil_moisture', 'ADC');
    
    if (sensorData.soil_moisture > 900) {
      criticalAlerts.push({
        type: 'SOIL_SENSOR_ISSUE',
        severity: 'HIGH',
        title: '🚨 SOIL MOISTURE SENSOR ALERT',
        message: `Soil moisture reading extremely high (${sensorData.soil_moisture} ADC)`,
        possible_causes: [
          'Sensor calibration needed',
          'Sensor not properly inserted in soil',
          'Dry soil conditions',
          'Sensor malfunction'
        ],
        action: 'Check sensor placement and calibration immediately',
        note: 'ADC 992 suggests very dry soil or incorrect reading'
      });
      healthScore -= 20;
    }
    else if (soilEval.status === 'OUT_OF_RANGE') {
      const isDry = sensorData.soil_moisture > soilEval.range[1];
      
      if (isDry) {
        recommendations.push({
          type: 'IRRIGATION',
          priority: 'HIGH',
          title: '🚰 Irrigation Required',
          message: `Soil is dry (ADC: ${sensorData.soil_moisture})`,
          action: 'Start irrigation for 20-30 minutes',
          duration: '20-30 minutes',
          frequency: 'Check again in 2 hours'
        });
        healthScore -= 25;
      } else {
        warnings.push({
          type: 'SOIL_TOO_WET',
          severity: 'MEDIUM',
          title: '💦 Soil May Be Too Wet',
          message: 'Low ADC value indicates wet soil',
          action: 'Delay irrigation, check drainage',
          risk: 'Root rot, fungal diseases'
        });
      }
    }
  }
  
  // Light Intensity Analysis
  if (sensorData.light !== null) {
    const lightEval = evaluateParameter(sensorData.light, 'light', 'lux');
    
    if (lightEval.status === 'OUT_OF_RANGE') {
      const isLow = sensorData.light < lightEval.range[0];
      
      recommendations.push({
        type: 'LIGHT',
        priority: isLow ? 'MEDIUM' : 'LOW',
        title: isLow ? '💡 Increase Light' : '🌤️ Reduce Light Exposure',
        message: `Light intensity (${sensorData.light} lux) ${isLow ? 'below' : 'above'} optimal`,
        action: isLow 
          ? 'Remove shading, clean greenhouse cover'
          : 'Apply shading during peak hours',
        optimal: `${lightEval.optimal[0]} - ${lightEval.optimal[1]} lux`
      });
      healthScore -= isLow ? 10 : 5;
    }
  }
  
  // CO2 Level Analysis
  if (sensorData.co2 !== null) {
    const co2Eval = evaluateParameter(sensorData.co2, 'co2', 'ppm');
    
    if (co2Eval.status === 'OUT_OF_RANGE' && sensorData.co2 > 1000) {
      recommendations.push({
        type: 'VENTILATION',
        priority: 'LOW',
        title: '🌬️ Ventilation Recommended',
        message: `CO2 level (${sensorData.co2} ppm) is elevated`,
        action: 'Increase ventilation for 15 minutes',
        benefit: 'Fresh air exchange improves plant health'
      });
    }
  }
  
  // Weather-based Recommendations
  if (weatherData) {
    if (weatherData.today.precipitation > 2) {
      recommendations.push({
        type: 'WEATHER',
        priority: 'MEDIUM',
        title: '🌧️ Rain Expected',
        message: `${weatherData.today.precipitation}mm precipitation forecasted`,
        action: 'Delay irrigation, ensure proper drainage'
      });
    }
    
    if (weatherData.today.max_temp > 30) {
      recommendations.push({
        type: 'WEATHER',
        priority: 'MEDIUM',
        title: '🔥 High Temperature Alert',
        message: `Max temperature today: ${weatherData.today.max_temp}°C`,
        action: 'Prepare cooling systems, increase watering'
      });
    }
  }
  
  // Growth Stage Specific Recommendations
  if (growthStage === 'tuber_formation') {
    recommendations.push({
      type: 'GROWTH_STAGE',
      priority: 'MEDIUM',
      title: '🥔 Tuber Formation Stage',
      message: 'Critical stage for tuber development',
      action: 'Ensure consistent soil moisture, avoid temperature stress',
      fertilizer: 'Use high-potassium fertilizer to promote tuber growth'
    });
  }
  
  if (growthStage === 'harvest') {
    recommendations.push({
      type: 'GROWTH_STAGE',
      priority: 'LOW',
      title: '🕒 Approaching Harvest',
      message: 'Plants nearing harvest time',
      action: 'Reduce watering 1-2 weeks before harvest',
      harvest_tip: 'Harvest on dry day, cure potatoes before storage'
    });
  }
  
  // Calculate final health
  const finalHealthScore = Math.max(0, Math.min(100, healthScore));
  
  let healthStatus, healthColor;
  if (finalHealthScore >= 85) {
    healthStatus = 'EXCELLENT'; healthColor = '🟢';
  } else if (finalHealthScore >= 70) {
    healthStatus = 'GOOD'; healthColor = '🟡';
  } else if (finalHealthScore >= 55) {
    healthStatus = 'FAIR'; healthColor = '🟠';
  } else if (finalHealthScore >= 40) {
    healthStatus = 'POOR'; healthColor = '🔴';
  } else {
    healthStatus = 'CRITICAL'; healthColor = '💀';
  }
  
  return {
    analysis_id: `analysis_${Date.now()}`,
    timestamp: new Date().toISOString(),
    growth_stage: growthStage,
    health: {
      score: finalHealthScore,
      status: healthStatus,
      color: healthColor,
      factors_checked: ['temperature', 'humidity', 'soil_moisture', 'light', 'co2', 'system']
    },
    recommendations: recommendations.sort((a, b) => {
      const priorityOrder = { 'CRITICAL': 0, 'HIGH': 1, 'MEDIUM': 2, 'LOW': 3 };
      return priorityOrder[a.priority] - priorityOrder[b.priority];
    }),
    warnings: warnings,
    critical_alerts: criticalAlerts,
    sensor_summary: sensorData,
    stage_info: {
      stage: growthStage,
      duration: stageData.duration_days,
      optimal_temp: stageData.temperature.optimal,
      optimal_humidity: stageData.humidity.optimal
    }
  };
}

async function performAIAnalysis() {
  try {
    console.log('🤖 Starting AI analysis...');
    
    // Get current farm state
    const farmStateSnapshot = await farmStateRef.once('value');
    if (!farmStateSnapshot.exists()) {
      throw new Error('No farm state data available');
    }
    
    const farmState = farmStateSnapshot.val();
    const greenhouseId = farmState.greenhouse_id || "GH_01";
    const sensorData = farmState.sensors || {};
    
    // Get system status
    const systemSnapshot = await systemRef.once('value');
    const systemData = systemSnapshot.val();
    const systemStatus = systemData?.status || {};
    
    // Detect growth stage
    const growthStage = detectGrowthStage();
    
    // Get weather data
    const weatherData = await getWeatherData(greenhouseId);
    
    // Perform analysis
    const analysis = analyzePotatoGrowth(sensorData, growthStage, weatherData, systemStatus);
    
    // Prepare complete result
    const result = {
      metadata: {
        greenhouse_id: greenhouseId,
        plant_type: farmState.plant_type || plantType,
        analysis_timestamp: new Date().toISOString(),
        data_source: 'sensora-68eda.firebasedatabase.app'
      },
      greenhouse_info: {
        greenhouse_id: greenhouseId,
        plant_type: farmState.plant_type || plantType,
        last_updated: farmState.last_updated
      },
      sensor_data: sensorData,
      weather_data: weatherData ? {
        current: weatherData.current,
        forecast: { today: weatherData.today, tomorrow: weatherData.tomorrow }
      } : null,
      system_status: {
        arduino_connected: systemStatus.arduino_connected || false,
        wifi_strength: systemStatus.wifi_strength || 0,
        free_memory: systemStatus.free_memory || 0,
        uptime: systemStatus.esp32_uptime || 0
      },
      ai_analysis: analysis
    };
    
    // Save to Firebase
    await saveAIAnalysisToFirebase(result);
    
    // Update local cache
    lastAnalysisResult = result;
    
    // Add to history (keep last 100)
    aiAnalysisHistory.unshift(result);
    if (aiAnalysisHistory.length > 100) {
      aiAnalysisHistory.pop();
    }
    
    console.log(`✅ AI analysis completed. Health: ${analysis.health.score}/100 - ${analysis.health.status}`);
    
    return result;
    
  } catch (error) {
    console.error('❌ Error performing AI analysis:', error);
    throw error;
  }
}

async function saveAIAnalysisToFirebase(analysisResult) {
  try {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const analysisId = `analysis_${timestamp}`;
    const greenhouseId = analysisResult.metadata.greenhouse_id;
    
    // Save full analysis
    await db.ref(`ai_analysis/full/${analysisId}`).set(analysisResult);
    
    // Save to greenhouse-specific latest analysis
    await db.ref(`ai_analysis/greenhouses/${greenhouseId}/latest`).set(analysisResult);
    
    // Save to history
    const historyEntry = {
      timestamp: analysisResult.metadata.analysis_timestamp,
      health_score: analysisResult.ai_analysis.health.score,
      health_status: analysisResult.ai_analysis.health.status,
      recommendations_count: analysisResult.ai_analysis.recommendations.length,
      warnings_count: analysisResult.ai_analysis.warnings.length,
      alerts_count: analysisResult.ai_analysis.critical_alerts.length
    };
    
    await db.ref(`ai_analysis/history/${greenhouseId}`).push().set(historyEntry);
    
    // Update dashboard
    await updateDashboard(analysisResult);
    
    console.log(`💾 AI analysis saved to Firebase: ${analysisId}`);
    
  } catch (error) {
    console.error('❌ Error saving AI analysis to Firebase:', error);
  }
}

async function updateDashboard(analysisResult) {
  try {
    const greenhouseId = analysisResult.metadata.greenhouse_id;
    const analysis = analysisResult.ai_analysis;
    
    const dashboardData = {
      last_updated: new Date().toISOString(),
      greenhouse: greenhouseId,
      plant_type: analysisResult.metadata.plant_type,
      health: {
        score: analysis.health.score,
        status: analysis.health.status,
        color: analysis.health.color
      },
      current_conditions: {
        temperature: analysisResult.sensor_data.temperature,
        humidity: analysisResult.sensor_data.humidity,
        soil_moisture: analysisResult.sensor_data.soil_moisture,
        light: analysisResult.sensor_data.light
      },
      alerts: analysis.critical_alerts.length > 0 ? analysis.critical_alerts[0] : null,
      top_recommendation: analysis.recommendations.length > 0 ? analysis.recommendations[0] : null,
      growth_stage: analysis.growth_stage,
      analysis_time: analysisResult.metadata.analysis_timestamp
    };
    
    await db.ref('dashboard').set(dashboardData);
    
    // Save to recent analyses
    const recentAnalysis = {
      timestamp: analysisResult.metadata.analysis_timestamp,
      greenhouse: greenhouseId,
      health_score: analysis.health.score,
      summary: `Health: ${analysis.health.score}/100 - ${analysis.health.status}`
    };
    
    await db.ref('recent_analyses').push().set(recentAnalysis);
    
  } catch (error) {
    console.error('❌ Error updating dashboard:', error);
  }
}

// ==================== Static File Serving ====================
const mimeTypes = {
  '.html': 'text/html',
  '.css': 'text/css',
  '.js': 'text/javascript',
  '.ico': 'image/x-icon',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.json': 'application/json'
};

function serveStaticFile(res, filePath) {
  const basePath = path.join(__dirname, 'Sensoura-Dashboard', 'Wired(Serial)V');
  let requestPath = filePath || '/';
  if (requestPath === '/') requestPath = '/index.html';

  const fullPath = path.join(basePath, requestPath);
  const resolvedPath = path.resolve(fullPath);
  const baseDir = path.resolve(basePath);

  if (!resolvedPath.startsWith(baseDir)) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    res.end('Forbidden');
    return;
  }

  const ext = path.extname(requestPath);
  const contentType = mimeTypes[ext] || 'text/plain';

  fs.readFile(fullPath, (err, data) => {
    if (err) {
      console.log(`File not found: ${fullPath}`);
      if (requestPath !== '/index.html') {
        const fallback = path.join(basePath, 'index.html');
        fs.readFile(fallback, (err2, data2) => {
          if (err2) {
            res.writeHead(404, { 'Content-Type': 'text/plain' });
            res.end('File not found');
          } else {
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(data2);
          }
        });
      } else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('File not found');
      }
    } else {
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(data);
    }
  });
}

// ==================== HTTP Server ====================
const server = http.createServer((req, res) => {
  if (req.url.startsWith('/api') || req.url.startsWith('/farm_state')) {
    app(req, res);
  } else {
    serveStaticFile(res, req.url);
  }
});

// ==================== Socket.io Setup ====================
const io = socketio(server, {
  cors: { 
    origin: "*", 
    methods: ["GET", "POST"],
    credentials: true
  }
});
global.ioInstance = io;

// ==================== Command Debounce ====================
let lastMuteTime = 0;
const MUTE_COOLDOWN = 1000;
let lastRelayTime = 0;
const RELAY_COOLDOWN = 500;

// ==================== Socket.io Handlers with AI Integration ====================
io.on('connection', socket => {
  console.log('🔌 Client connected:', socket.id);

  socket.emit('connectionStatus', {
    connected: true,
    arduinoConnected: false,
    timestamp: new Date().toISOString(),
    ai_enabled: true
  });

  // Send current plant type
  socket.emit('currentPlantType', {
    plantType: plantType,
    timestamp: new Date().toISOString()
  });

  // Send current farm state if available
  if (currentFarmState) {
    socket.emit('currentFarmState', currentFarmState);
  }

  // Send latest AI analysis if available
  if (lastAnalysisResult) {
    socket.emit('aiAnalysisUpdate', lastAnalysisResult);
  }

  // =============== AI Analysis Events ===============
  
  // Trigger AI analysis
  socket.on('triggerAIAnalysis', async () => {
    try {
      socket.emit('aiAnalysisStatus', {
        status: 'processing',
        message: 'AI analysis in progress...',
        timestamp: new Date().toISOString()
      });
      
      const analysis = await performAIAnalysis();
      
      // Broadcast to all clients
      io.emit('aiAnalysisUpdate', analysis);
      
      socket.emit('aiAnalysisStatus', {
        status: 'completed',
        message: 'AI analysis completed successfully',
        timestamp: new Date().toISOString()
      });
      
    } catch (error) {
      console.error('❌ Error in manual AI analysis:', error);
      socket.emit('aiAnalysisStatus', {
        status: 'error',
        message: 'Failed to perform AI analysis',
        timestamp: new Date().toISOString()
      });
    }
  });

  // Get AI analysis history
  socket.on('getAIAnalysisHistory', async (data) => {
    try {
      const { limit = 10 } = data || {};
      const historyRef = db.ref('ai_analysis/history/GH_01');
      const snapshot = await historyRef.limitToLast(parseInt(limit)).once('value');
      
      if (snapshot.exists()) {
        const historyData = [];
        snapshot.forEach(child => {
          historyData.unshift({
            id: child.key,
            ...child.val()
          });
        });
        
        socket.emit('aiAnalysisHistory', {
          success: true,
          history: historyData,
          count: historyData.length
        });
      } else {
        socket.emit('aiAnalysisHistory', {
          success: false,
          message: 'No AI analysis history available'
        });
      }
    } catch (error) {
      console.error('❌ Error fetching AI analysis history:', error);
      socket.emit('aiAnalysisHistoryError', {
        message: 'Failed to fetch AI analysis history'
      });
    }
  });

  // Get current AI analysis
  socket.on('getCurrentAIAnalysis', () => {
    if (lastAnalysisResult) {
      socket.emit('aiAnalysisUpdate', lastAnalysisResult);
    } else {
      socket.emit('aiAnalysisStatus', {
        status: 'no_data',
        message: 'No AI analysis available. Run analysis first.',
        timestamp: new Date().toISOString()
      });
    }
  });

  // Subscribe to AI analysis updates
  socket.on('subscribeToAIUpdates', () => {
    socket.join('ai_updates');
    console.log(`👤 Client ${socket.id} subscribed to AI updates`);
    
    socket.emit('aiSubscriptionStatus', {
      subscribed: true,
      message: 'Subscribed to AI analysis updates',
      timestamp: new Date().toISOString()
    });
  });

  // =============== Existing Events ===============
  
  // Handle plant type update
  socket.on('updatePlantType', async (data) => {
    try {
      const { plantType: newPlantType } = data;
      
      if (!newPlantType || typeof newPlantType !== 'string') {
        socket.emit('plantTypeUpdateResponse', {
          success: false,
          message: 'Invalid plant type'
        });
        return;
      }
      
      plantType = newPlantType;
      
      await farmStateRef.update({ plant_type: plantType });
      
      console.log(`🌱 Plant type updated to: ${plantType}`);
      
      socket.emit('plantTypeUpdateResponse', {
        success: true,
        plantType: plantType,
        message: 'Plant type updated successfully',
        timestamp: new Date().toISOString()
      });
      
      io.emit('plantTypeUpdated', {
        plantType: plantType,
        timestamp: new Date().toISOString()
      });
      
    } catch (error) {
      console.error('❌ Error updating plant type:', error);
      socket.emit('plantTypeUpdateResponse', {
        success: false,
        message: 'Failed to update plant type'
      });
    }
  });

  // Get plant type
  socket.on('getPlantType', () => {
    socket.emit('currentPlantType', {
      plantType: plantType,
      timestamp: new Date().toISOString()
    });
  });

  // Get farm state history
  socket.on('getFarmStateHistory', async (data) => {
    try {
      const { limit = 50 } = data || {};
      const snapshot = await farmStateHistoryRef.orderByChild('timestamp').limitToLast(parseInt(limit)).once('value');
      
      if (!snapshot.exists()) {
        socket.emit('farmStateHistory', { history: [] });
        return;
      }

      const historyData = [];
      snapshot.forEach(child => {
        historyData.unshift({
          id: child.key,
          ...child.val()
        });
      });

      socket.emit('farmStateHistory', {
        count: historyData.length,
        history: historyData
      });
    } catch (error) {
      console.error('❌ Error fetching farm state history:', error);
      socket.emit('farmStateHistoryError', { message: 'Failed to fetch history' });
    }
  });

  // Control events
  socket.on('muteToggle', (isMuted) => {
    const now = Date.now();
    if (now - lastMuteTime < MUTE_COOLDOWN) {
      socket.emit('muteStatus', { success: false, message: 'Please wait before toggling mute again' });
      return;
    }
    lastMuteTime = now;
    controlArduinoBuzzer(isMuted, 'dashboard', socket.id);
  });

  socket.on('relayToggle', (isOn) => {
    const now = Date.now();
    if (now - lastRelayTime < RELAY_COOLDOWN) {
      socket.emit('relayStatus', { success: false, message: 'Please wait before toggling relay again' });
      return;
    }
    lastRelayTime = now;
    controlArduinoRelay(isOn ? 'ON' : 'OFF', 'dashboard', socket.id);
  });

  socket.on('relayModeToggle', (mode) => {
    const now = Date.now();
    if (now - lastRelayTime < RELAY_COOLDOWN) {
      socket.emit('relayStatus', { success: false, message: 'Please wait before changing relay mode' });
      return;
    }
    lastRelayTime = now;
    controlArduinoRelay(mode, 'dashboard', socket.id);
  });

  // Status requests
  socket.on('getMuteStatus', () => {
    socket.emit('muteStatus', { success: true, muted: false, message: 'Mute status retrieved' });
  });

  socket.on('getRelayStatus', () => {
    socket.emit('relayStatus', { success: true, relayOn: false, relayMode: 'AUTO', message: 'Relay status retrieved' });
  });

  socket.on('getSystemStatus', () => {
    socket.emit('systemStatus', {
      online: true,
      firebaseConnected: true,
      arduinoConnected: false,
      ai_enabled: true,
      last_analysis: lastAnalysisResult?.timestamp || null,
      timestamp: new Date().toISOString()
    });
  });

  socket.on('getDashboardData', async () => {
    try {
      const dashboardRef = db.ref('dashboard');
      const snapshot = await dashboardRef.once('value');
      
      if (snapshot.exists()) {
        socket.emit('dashboardData', snapshot.val());
      }
    } catch (error) {
      console.error('❌ Error fetching dashboard data:', error);
    }
  });

  socket.on('disconnect', () => {
    console.log('🔌 Client disconnected:', socket.id);
    socket.leave('ai_updates');
  });
});

// ==================== Control Functions ====================
async function controlArduinoBuzzer(isMuted, sentBy = 'dashboard', socketId = '') {
  const command = isMuted ? 'MUTE' : 'UNMUTE';
  console.log(`🔊 Sending buzzer command to Firebase: ${command} from ${sentBy}`);

  try {
    const timestamp = new Date().toISOString();
    const commandData = { action: command, timestamp, sentBy, socketId, status: 'pending' };

    const newCommandRef = commandsRef.push();
    await newCommandRef.set(commandData);

    console.log(`✅ Buzzer command saved to Firebase: ${command}`);

    io.emit('muteStatus', { success: true, muted: isMuted, message: `Command sent to Arduino: ${command}`, timestamp, commandId: newCommandRef.key });

  } catch (error) {
    console.error('❌ Error sending buzzer command to Firebase:', error);
    io.emit('muteStatus', { success: false, message: 'Failed to send command to Arduino' });
  }
}

async function controlArduinoRelay(command, sentBy = 'dashboard', socketId = '') {
  console.log(`⚡ Sending relay command to Firebase: ${command} from ${sentBy}`);

  const validCommands = ['ON', 'OFF', 'AUTO'];
  if (!validCommands.includes(command)) {
    console.error(`❌ Invalid relay command: ${command}`);
    io.emit('relayStatus', { success: false, message: 'Invalid relay command' });
    return;
  }

  try {
    const timestamp = new Date().toISOString();
    const commandData = { action: command, timestamp, sentBy, socketId, status: 'pending', type: 'relay' };

    const newCommandRef = relayCommandsRef.push();
    await newCommandRef.set(commandData);

    console.log(`✅ Relay command saved to Firebase: ${command}`);

    io.emit('relayStatus', {
      success: true,
      relayOn: command === 'ON',
      relayMode: command === 'AUTO' ? 'AUTO' : 'MANUAL',
      message: `Relay command sent to Arduino: ${command}`,
      timestamp,
      commandId: newCommandRef.key
    });

  } catch (error) {
    console.error('❌ Error sending relay command to Firebase:', error);
    io.emit('relayStatus', { success: false, message: 'Failed to send relay command to Arduino' });
  }
}

// ==================== Data Processing Functions ====================
function extractSensorData(firebaseData) {
  if (typeof firebaseData === 'object' && firebaseData !== null) {
    const keys = Object.keys(firebaseData);
    for (const key of keys) {
      const data = firebaseData[key];
      if (typeof data === 'object' && data !== null) {
        if (data.gas !== undefined || data.temperature !== undefined || data.soil !== undefined || data.humidity !== undefined || data.light !== undefined) {
          return data;
        }
      }
    }
  }
  return firebaseData;
}

function parseSensorData(rawData) {
  const data = extractSensorData(rawData);
  if (!data || typeof data !== 'object') return null;

  const hasValidData = data.gas !== undefined || data.soil !== undefined || data.temperature !== undefined || data.humidity !== undefined || data.light !== undefined;
  if (!hasValidData) return null;

  return {
    gas: data.gas || 0,
    soil: data.soil || 0,
    temperature: data.temperature || data.tmp || 0,
    humidity: data.humidity || 0,
    light: data.light || 0,
    gas_status: data.gas_status || "Unknown",
    soil_status: data.soil_status || "Unknown",
    temperature_status: data.temperature_status || "Unknown",
    humidity_status: data.humidity_status || "Unknown",
    light_status: data.light_status || "Unknown",
    system_status: data.system_status || "Unknown",
    arduino_buzzer_state: data.arduino_buzzer_state || "UNKNOWN",
    buzzer_state: data.buzzer_state || "UNKNOWN",
    relay_state: data.relay_state || "UNKNOWN",
    relay_mode: data.relay_mode || "AUTO",
    arduino_connected: data.arduino_connected || false,
    local_time: data.local_time || new Date().toLocaleString(),
    utc_time: data.utc_time || new Date().toISOString(),
    timestamp: data.timestamp || new Date().toISOString(),
    tmp: data.temperature || data.tmp || 0
  };
}

// ==================== Farm State Management ====================
async function updateFarmState(sensorData) {
  try {
    const now = new Date().toISOString();
    
    // Calculate derived values
    const heatIndex = sensorData.heat_index || calculateHeatIndex(
      sensorData.temperature || sensorData.tmp || 0,
      sensorData.humidity || 0
    );
    
    const vpd = sensorData.vpd || calculateVPD(
      sensorData.temperature || sensorData.tmp || 0,
      sensorData.humidity || 0
    );
    
    // Get current farm state
    const currentStateSnapshot = await farmStateRef.once('value');
    let currentState = currentFarmState || {};
    
    if (currentStateSnapshot.exists()) {
      currentState = currentStateSnapshot.val();
    }
    
    // Update relay runtime if relay state changed
    let totalRuntime = currentState.actuators?.irrigation_relay?.total_runtime_sec || 0;
    let lastOn = currentState.actuators?.irrigation_relay?.last_on || now;
    let lastOff = currentState.actuators?.irrigation_relay?.last_off || now;
    
    const relayState = sensorData.relay_state || "OFF";
    const currentRelayState = currentState.actuators?.irrigation_relay?.state || "OFF";
    
    if (relayState === "ON" && currentRelayState === "OFF") {
      lastOn = now;
    } else if (relayState === "OFF" && currentRelayState === "ON") {
      lastOff = now;
      const onTime = new Date(lastOn).getTime();
      const offTime = new Date(lastOff).getTime();
      const runtime = Math.floor((offTime - onTime) / 1000);
      totalRuntime += runtime;
    }
    
    // Prepare updated farm state
    const updatedFarmState = {
      greenhouse_id: "GH_01",
      sensors: {
        temperature: sensorData.temperature || sensorData.tmp || 0,
        humidity: sensorData.humidity || 0,
        soil_moisture: sensorData.soil || 0,
        light: sensorData.light || 0,
        co2: sensorData.gas || 0,
        timestamp: sensorData.timestamp || now
      },
      actuators: {
        irrigation_relay: {
          state: relayState,
          last_on: lastOn,
          last_off: lastOff,
          total_runtime_sec: totalRuntime
        }
      },
      derived: {
        heat_index: heatIndex,
        vpd: vpd
      },
      plant_type: plantType,
      last_updated: now
    };
    
    // Update current state
    await farmStateRef.set(updatedFarmState);
    
    // Add to historical data
    const historyEntry = {
      ...updatedFarmState,
      recorded_at: now
    };
    
    await farmStateHistoryRef.push().set(historyEntry);
    
    // Update local cache
    currentFarmState = updatedFarmState;
    
    // Emit to all clients
    if (global.ioInstance) {
      global.ioInstance.emit('farmStateUpdated', updatedFarmState);
      global.ioInstance.emit('farmStateHistoryAdded', {
        id: Date.now().toString(),
        ...historyEntry
      });
    }
    
    console.log("✅ Farm state updated");
    return true;
  } catch (error) {
    console.error('❌ Error updating farm state:', error);
    return false;
  }
}

function calculateHeatIndex(temperature, humidity) {
  if (temperature < 27 || humidity < 40) {
    return temperature;
  }
  
  const T = temperature;
  const R = humidity;
  const c1 = -42.379;
  const c2 = 2.04901523;
  const c3 = 10.14333127;
  const c4 = -0.22475541;
  const c5 = -6.83783e-3;
  const c6 = -5.481717e-2;
  const c7 = 1.22874e-3;
  const c8 = 8.5282e-4;
  const c9 = -1.99e-6;
  
  return c1 + (c2 * T) + (c3 * R) + (c4 * T * R) + 
         (c5 * T * T) + (c6 * R * R) + (c7 * T * T * R) + 
         (c8 * T * R * R) + (c9 * T * T * R * R);
}

function calculateVPD(temperature, humidity) {
  const svp = 0.6108 * Math.exp((17.27 * temperature) / (temperature + 237.3));
  const avp = (humidity / 100) * svp;
  return svp - avp;
}

// ==================== Scheduled Tasks ====================
function setupScheduledTasks() {
  console.log('⏰ Setting up scheduled tasks...');
  
  // AI analysis every 15 minutes
  cron.schedule('*/15 * * * *', async () => {
    console.log('🤖 Scheduled AI analysis triggered...');
    try {
      const analysis = await performAIAnalysis();
      
      // Broadcast to all clients in the ai_updates room
      io.to('ai_updates').emit('aiAnalysisUpdate', analysis);
      console.log('✅ Scheduled AI analysis completed and broadcasted');
      
    } catch (error) {
      console.error('❌ Scheduled AI analysis failed:', error);
    }
  });
  
  // Run AI analysis 1 minute after startup
  setTimeout(async () => {
    console.log('🤖 Running initial AI analysis...');
    try {
      await performAIAnalysis();
      console.log('✅ Initial AI analysis completed');
    } catch (error) {
      console.error('❌ Initial AI analysis failed:', error);
    }
  }, 60000);
  
  console.log('✅ Scheduled tasks configured');
}

// ==================== Firebase Listeners ====================
function setupFirebaseListeners() {
  console.log("📡 Setting up Firebase listeners...");

  try {
    sensorRef.off();
    commandsRef.off();
    relayCommandsRef.off();
    db.ref("buzzer_state").off();
    db.ref("relay_state").off();
  } catch (err) {
    console.warn("⚠️ Error turning off previous listeners:", err.message);
  }

  const limitedSensorRef = sensorRef.limitToLast(1);

  limitedSensorRef.on("child_added", async (snapshot) => {
    const rawData = snapshot.val();
    console.log("📊 RAW Firebase data received (child_added)");

    const sensorData = parseSensorData(rawData);
    if (!sensorData) return;

    console.log("📈 Parsed sensor data:", sensorData);

    // Update farm_state with new sensor data
    await updateFarmState(sensorData);

    // Emit sensor data to all clients
    io.emit("sensorData", sensorData);
    
    // Trigger AI analysis on significant data change
    if (currentFarmState) {
      const oldTemp = currentFarmState.sensors?.temperature || 0;
      const newTemp = sensorData.temperature || 0;
      
      if (Math.abs(oldTemp - newTemp) > 2) {
        console.log('🌡️ Significant temperature change detected, triggering AI analysis...');
        setTimeout(async () => {
          try {
            const analysis = await performAIAnalysis();
            io.to('ai_updates').emit('aiAnalysisUpdate', analysis);
          } catch (error) {
            console.error('❌ Auto AI analysis failed:', error);
          }
        }, 5000);
      }
    }
  });

  sensorRef.on("child_changed", async (snapshot) => {
    const rawData = snapshot.val();
    console.log("📊 RAW Firebase data updated");

    const sensorData = parseSensorData(rawData);
    if (!sensorData) return;

    console.log("📈 UPDATED sensor data:", sensorData);

    // Update farm_state with updated sensor data
    await updateFarmState(sensorData);

    io.emit("sensorData", sensorData);
  });

  commandsRef.on("child_changed", (snapshot) => {
    const command = snapshot.val();
    if (command && command.status === 'completed') {
      console.log(`🔊 Buzzer command executed: ${command.action}`);

      io.emit('commandExecuted', {
        action: command.action,
        executedAt: command.executedAt || new Date().toISOString(),
        sentBy: command.sentBy
      });
    }
  });

  relayCommandsRef.on("child_changed", (snapshot) => {
    const command = snapshot.val();
    if (command && command.status === 'completed') {
      console.log(`⚡ Relay command executed: ${command.action}`);

      io.emit('relayCommandExecuted', {
        action: command.action,
        executedAt: command.executedAt || new Date().toISOString(),
        sentBy: command.sentBy
      });
    }
  });

  const buzzerStateRef = db.ref("buzzer_state");
  buzzerStateRef.on("value", (snapshot) => {
    const buzzerState = snapshot.val();
    if (buzzerState !== null && buzzerState !== undefined) {
      console.log(`🔊 Buzzer state updated: ${buzzerState}`);
      io.emit('buzzerStateUpdate', {
        state: buzzerState,
        timestamp: new Date().toISOString()
      });
    }
  });

  const relayStateRef = db.ref("relay_state");
  relayStateRef.on("value", (snapshot) => {
    const relayState = snapshot.val();
    if (relayState !== null && relayState !== undefined) {
      console.log(`⚡ Relay state updated: ${relayState}`);
      io.emit('relayStateUpdate', {
        state: relayState,
        timestamp: new Date().toISOString()
      });
    }
  });
}

// ==================== Initialize Farm State ====================
async function initializeFarmState() {
  try {
    const currentSnapshot = await farmStateRef.once('value');
    
    if (!currentSnapshot.exists()) {
      const initialFarmState = {
        greenhouse_id: "GH_01",
        sensors: {
          temperature: 0,
          humidity: 0,
          soil_moisture: 0,
          light: 0,
          co2: 0,
          timestamp: new Date().toISOString()
        },
        actuators: {
          irrigation_relay: {
            state: "OFF",
            last_on: new Date().toISOString(),
            last_off: new Date().toISOString(),
            total_runtime_sec: 0
          }
        },
        derived: {
          heat_index: 0,
          vpd: 0
        },
        plant_type: plantType,
        last_updated: new Date().toISOString()
      };
      
      await farmStateRef.set(initialFarmState);
      currentFarmState = initialFarmState;
      console.log("✅ Initial farm_state created in Firebase");
    } else {
      currentFarmState = currentSnapshot.val();
      if (currentFarmState.plant_type) {
        plantType = currentFarmState.plant_type;
        console.log(`🌱 Loaded plant type from Firebase: ${plantType}`);
      }
      console.log("✅ Loaded existing farm state from Firebase");
    }
    
    const historySnapshot = await farmStateHistoryRef.limitToLast(1).once('value');
    if (!historySnapshot.exists()) {
      const initialHistoryEntry = {
        ...currentFarmState,
        recorded_at: new Date().toISOString()
      };
      await farmStateHistoryRef.push().set(initialHistoryEntry);
      console.log("📝 Initial farm state added to history");
    }
    
  } catch (error) {
    console.error('❌ Error initializing farm_state:', error);
  }
}

// ==================== Server Startup ====================
async function startServer() {
  try {
    console.log('\n' + '='.repeat(60));
    console.log('🚀 SENSORA AI INTEGRATED SYSTEM STARTING');
    console.log('🤖 AI Analysis + Real-time Control + Dashboard');
    console.log('='.repeat(60));

    // Initialize farm state in Firebase
    await initializeFarmState();
    
    // Setup Firebase listeners
    setupFirebaseListeners();
    
    // Setup scheduled tasks (including AI analysis)
    setupScheduledTasks();

    const PORT = process.env.PORT || 5000;
    server.listen(PORT, () => {
      console.log(`\n✅ Server running on http://localhost:${PORT}`);
      console.log('📡 Connected to Firebase Realtime Database');
      console.log('🤖 AI Analysis System: ACTIVE (every 15 minutes)');
      console.log('🔊 Buzzer Control System: ACTIVE');
      console.log('⚡ Relay Control System: ACTIVE');
      console.log('🌱 Plant Type Management: ACTIVE');
      console.log('\n📊 Available Endpoints:');
      console.log('   - GET /api/ai/analysis - Get AI analysis results');
      console.log('   - POST /api/ai/analyze - Trigger manual AI analysis');
      console.log('   - GET /api/dashboard - Get dashboard data');
      console.log('   - GET /farm_state - Current farm state');
      console.log('   - GET /farm_state/history - Historical data');
      console.log('\n🔌 Socket.io Events:');
      console.log('   - triggerAIAnalysis - Run AI analysis');
      console.log('   - getCurrentAIAnalysis - Get latest analysis');
      console.log('   - subscribeToAIUpdates - Get real-time AI updates');
      console.log('   - updatePlantType - Change plant type');
      console.log('\n🤖 Ready for real-time monitoring and AI-powered insights!');
    });

  } catch (err) {
    console.error('❌ Error starting server:', err);
    process.exit(1);
  }
}

// ==================== Error Handling ====================
process.on('uncaughtException', error => {
  console.error('❌ Uncaught Exception:', error);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Unhandled Rejection at:', promise, 'reason:', reason);
});

// ==================== Start Application ====================
startServer();